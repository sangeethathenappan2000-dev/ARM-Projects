#include <lpc214x.h>
#include "lcd.c"
#include"delay.h"
#include "defines.h"
#include"can.c"
#include "spi.c"


int main(void)
{	CAN_MSG m1;
	float moist=0;
		
	lcd_init();
	can_init();
	m1.id=0x02;
	m1.dlc=4;
	m1.rtr=0;

	lcd_command(0x80);
	lcd_str("Moisture level:");

	while(1)
	{
	    moist=mcp3204_read(0);
		m1.AByte=moist;
		lcd_command(0xc0);
		lcd_float(moist);
		delay_ms(3000);

		can_tx(m1);
		delay_ms(300);;

	
	}
}