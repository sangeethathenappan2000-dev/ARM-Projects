#include <LPC21xx.H>

#include "lcd.c"
#include "delay.h"
#include "defines.h"
#include"can.c"

#define outpin 14
int main(void)
{	CAN_MSG m1;
	f32 emp_in=0;

	lcd_init();
	can_init();

	m1.id=0x01;
	m1.dlc=4;
	m1.rtr=0;

	while(1)
	{
		lcd_command(0x80);	
		lcd_str("EMP IN:");

		if(((IOPIN0>>outpin)&1)==0 )
		emp_in++;

		lcd_integer(emp_in);

		m1.AByte=emp_in;

	delay_ms(5000);

	can_tx(m1);
	}
}
