#include "delay.h"

#define LED 1<<0

int main()
{
unsigned char i;
PINSEL0=0;
IODIR0=0xff;
 IOSET0=0XFF;
while(1)
{
	for(i=0;i<8;i++)
	{	IOCLR0=LED<<i;
		delay_ms(100);
		IOSET0=LED<<i;
		delay_ms(100);
	}
}
}
