#include "delay.h"

#define LED 1<<0

int main()
{	unsigned char i,j;
	IODIR0=0XFF;
	IOSET0=0XFF;
	while(1)
	{  for(i=0,j=7;(i<4)&&(j>=4);i++,j--)
		{
		IOCLR0=(LED<<i)|(LED<<j);
		delay(1);
		IOSET0=(LED<<i)|(LED<<j);
		delay(1);
		}
		for(i=3,j=4;(i>=0)&&(j<8);i--,j++)
		{
		IOCLR0=(LED<<i)|(LED<<j);
		delay(1);
		IOSET0=(LED<<i)|(LED<<j);
		delay(1);
		}
	}
}
