#include "delay.h"
#define LED 1<<0
int main()
{

PINSEL0=0;
IODIR0=LED;
while(1)
{
IOCLR0=LED;
delay(1);
IOSET0=LED;
delay(1);
}
}
