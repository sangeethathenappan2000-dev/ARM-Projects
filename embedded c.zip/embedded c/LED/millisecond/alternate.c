/*ECP to produce delay using timer0  */

#include"delay.h"

int main()
{

PINSEL0=0x00;
IODIR0=0xFF;
IOSET0=0XFF;
while(1)
{

	IOCLR0=0x01;	
	delay(1);
	IOSET0=0x01;
	delay(1);
	IOCLR0=0x02;
	delay(1);
	IOSET0=0x02;
	delay(1);
	IOCLR0=0x04;
	delay(1);
	IOSET0=0x04;
	delay(1);
	IOCLR0=0x08;
	delay(1);
	IOSET0=0x08;
	delay(1);
	IOCLR0=0x10;
	delay(1);
	IOSET0=0x10;
	delay(1);
	IOCLR0=0x20;
	delay(1);
	IOSET0=0x20;
	delay(1);
	IOCLR0=0x40;
	delay(1);
	IOSET0=0x40;
	delay(1);
	IOCLR0=0x80;
	delay(1);
	IOSET0=0x80;
	delay(1);
	IOCLR0=0xFF;
	delay(1);
	IOSET0=0XFF;
	delay(1);
			
}}
