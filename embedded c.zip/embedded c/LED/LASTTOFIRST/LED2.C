#include"delay.h"


int main()
{

PINSEL0=0X00;
IODIR0=0XFF;
IOSET0=0XFF;

while(1)
{

IOCLR0=0X01|0X10;
delay(1);
IOSET0=0X01|0X10;
delay(1);
 IOCLR0=0X02|0X20;
delay(1);
IOSET0=0X02|0X20;
delay(1);
IOCLR0=0X04|0X40;
delay(1);
IOSET0=0X04|0X40;
delay(1);
IOCLR0=0X08|0X80;
delay(1);
IOSET0=0X08|0X80;

delay(1);

}
}
