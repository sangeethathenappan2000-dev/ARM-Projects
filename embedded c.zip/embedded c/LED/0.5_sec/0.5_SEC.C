#include "delay.h"

#define LED 1<<0

int main()
{
PINSEL0=0;

while(1)
{
IODIR0=LED;
IOCLR0=LED;
delay_ms(500);
IOSET0=LED;
delay_ms(500);
}
}
