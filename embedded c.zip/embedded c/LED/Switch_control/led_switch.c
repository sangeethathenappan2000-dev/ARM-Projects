#include "delay.h"

#define LED1 1<<0
#define LED2 1<<1
#define sw1 2
#define sw2 3


int main()
{
	IODIR0=LED1|LED2;
	IOSET0=LED1|LED2;
	while(1)
	{
	if(((IOPIN0>>sw1)&1)==0)
		{
			IOCLR0=LED1;
			delay(1);
			IOSET0=LED1;
			delay(1);
		}	
	else if(((IOPIN0>>sw2)&1)==0)
	{
		IOCLR0=LED2;
		delay(1);
		IOSET0=LED2;
		delay(1);
		}

}
}


