#include "delay.h"

#define LED1 1<<0
#define LED2 1<<1
#define LED3 1<<2
#define LED4 1<<3
#define LED5 1<<4
#define LED6 1<<5
#define LED7 1<<6
#define LED8 1<<7

int main()
{
	IODIR0=0XFF;
	IOSET0=0XFF;
	while(1)
	{
	IOCLR0=LED2|LED4|LED6|LED8;
	delay(1);
	IOSET0=LED2|LED4|LED6|LED8;
	delay(1);
	}
}
