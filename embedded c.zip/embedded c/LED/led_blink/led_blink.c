#include<lpc21xx.h>

#define led1 1<<17
#define led2 1<<18

void delay(int x)
{
int j;
for(;x>0;x--)
	for(j=12000;j>0;j--);
}
int main()
{
int i=5;
PINSEL0=0;
//PINFSEL2=0;
IODIR0=led2|led1;
while(1)
	{
	IOCLR0=led1;
	delay(500);
	IOSET0=led1;
	IOCLR0=led2;
	delay(500);
	IOSET0=	led2;
		//i--;
	}

}
