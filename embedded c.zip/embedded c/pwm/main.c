#include <lpc21xx.h>

#include <stdint.h>

#include"lcd.h"

#define sw1 14




int main(void)

{

  int value,i;
	

    PINSEL0 |=0x00000008; /* Configure P0.1 as PWM3 */

    PWMTCR = 0x02; /* Reset and disable counter for PWM */

    PWMPR = 0x1D; /* 29 Prescale Register value  */

    PWMMR0 = 20000; /* Time period f PWM wave, 20msec */

    PWMMR3 = 1000; /* Ton of PWM wave 1 msec */

    PWMMCR = 0x00000002; /* Reset on MR0 match*/

    PWMLER = 0x09; /* Latch enable for PWM3 and PWM0 */

    PWMPCR = 0x0800; /* Enable PWM3 and PWM 0, single edge controlled PWM */

    PWMTCR = 0x09; /* Enable PWM and counter */


  while (1)

    {

	  if(((IOPIN0 >> sw1) & 1) == 0)

	   {

	   for(i=0; i<5; i++)

	   {

	    value=500; //0

        PWMMR3 = value; 

        PWMLER = 0x08;

		lcd_command(0Xc5);

		lcd_integer(value);

		delay_ms(500); 


		value=1000;//90

		PWMMR3 = value;

        PWMLER = 0x08;

	    lcd_command(0Xc5);

		lcd_integer(value);

		delay_ms(500);

	  

    }

 }

 }

 }

