#include<LPC21XX.H>
#define buzzer 1<<21
#define led 1<<18

void DELAY(int x)
{
T0PR=15000000-1;
T0TCR=0X01;
while(T0TC<x);
T0TCR=0X03;
T0TCR=0X00;
}

int main()
{
PINSEL0=0;
IODIR0=	buzzer|led;
while(1)
{
if(((IOPIN0>>14)&1)==0	)
{
	IOCLR0=led;
    DELAY(2);
	IOSET0=buzzer|led;
	DELAY(5);
	IOCLR0=buzzer;
	DELAY(5);
}
}
}
