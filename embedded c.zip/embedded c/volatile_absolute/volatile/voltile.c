	  #include<lpc21xx.h>

	  int main()
	  {
	  	volatile unsigned int *ptr=(int *)0x40000000;
		volatile int temp= *ptr;
		while(1)
		{
		if(!temp)
		break;
		}
		}
