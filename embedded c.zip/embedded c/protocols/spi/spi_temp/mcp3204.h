#ifndef __MCP3204_H__
#define __MCP3204_H__

#include "types.h"
	
f32 Read_ADC_MCP3204(u8 channelNo);

#endif
