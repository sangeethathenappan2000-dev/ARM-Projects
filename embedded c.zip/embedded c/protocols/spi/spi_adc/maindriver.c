                    /* main_hwspi_mcp3204_lcd_test.c */

#include <LPC21xx.h>

#include "types.h"

#include "spi.h"

#include "mcp3204.h"

#include "4bitmode.h"


main()

{

	f32 f,temp;

	Init_SPI0(); //hw SPI initialisation

	lcd_init();
	lcd_command(0x80);	

	lcd_str("TEMP: ");

	

	IOPIN0 |= 1<<7;

  while(1)

  {

    	f=Read_ADC_MCP3204(0);
		//delay_ms(10);

		lcd_command(0xc0);
		temp=f*100.0;

		lcd_float(temp);
		delay_ms(500);

	}	

}



