//MCP3204 HEADER

#ifndef MCP3204_H
#define MCP3204_H

#include "types.h"

f32 read_mcp3204(u8);
#endif

