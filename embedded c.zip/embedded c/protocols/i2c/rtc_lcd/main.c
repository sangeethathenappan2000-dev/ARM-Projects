#include <LPC21xx.h>
#include"eeprom_header.h"
#include "4bitmode.h"



int main()
{
	u8 sec,min,hour;

	lcd_init();
	init_i2c();

	i2c_eeprom_write(0x68,0x00,0x45);
	i2c_eeprom_write(0x68,0x01,0x30);
    i2c_eeprom_write(0x68,0x02,0x11);

	while(1)
	{
	sec=i2c_eeprom_read(0x68,0x00);
	min=i2c_eeprom_read(0x68,0x01);
	hour=i2c_eeprom_read(0x68,0x02);


	lcd_command(0x80);
	lcd_data(hour);
	lcd_data(':');
	lcd_data(min);
	lcd_data(':');
	lcd_data(sec);

	delay_sec(500);
	lcd_command(0x01);
	}
}

