#include "delay.h"
#include "i2c.c"
typedef unsigned char u8;

void i2c_rtc_write(u8,u8,u8);

unsigned char i2c_rtc_read(u8,u8);

void i2c_rtc_write(u8 slave,u8 word,u8 dat)
{
	i2c_start();
	i2c_write(slave<<1);
	i2c_write(word);
	i2c_write(dat);
	i2c_stop();
	delay_ms(10);
}

u8 i2c_rtc_read(u8 slave,u8 word)
{	u8 ch;
	i2c_start();
	i2c_write(slave<<1);
	i2c_write(word);
	i2c_restart();
	i2c_write(slave<<1|1);
	ch=i2c_nack();
	i2c_stop();
	return ch;


}


