typedef unsigned char u8;


void init_i2c(void);

void i2c_start(void);

void i2c_stop(void);

void i2c_restart(void);

void i2c_write(u8);

u8 i2c_nack(void);

#define sta_bit 5
#define sto_bit 4
#define si_bit 3
#define i2c_en 1<<6
#define cclk 60000000
#define pclk cclk/4
#define i2c_speed 100000
#define load_val (pclk/i2c_speed)/2

void i2c_write(u8 wBytes)
{
	I2DAT=wBytes;	//writing the data on I2DAT register
	I2CONCLR=1<<si_bit;   //clearing the previous SI flag
	while(((I2CONSET>>si_bit)&1)==0); //waiting until SI flag is set
}
	
void i2c_start()
{
	   I2CONSET=1<<sta_bit;
	   while(((I2CONSET>>si_bit)&1)==0);
	   I2CONCLR=1<<sta_bit;
}

void i2c_init()
{
	PINSEL0|=0x50;
	I2SCLL=load_val;
	 I2SCLH=load_val;
	 I2CONSET=i2c_en;
}

void i2c_stop()
{
	I2CONSET=1<<sto_bit;
	I2CONCLR=1<<si_bit;

}

void i2c_restart()
{
	 I2CONSET=sta_bit;
	 I2CONCLR=1<<si_bit;
	 while(((I2CONSET>>si_bit)&1)==0);
	 I2CONCLR=sta_bit;
}

u8 i2c_nack()
{
	I2CONSET = 0x00; //Assert Not of Ack
    I2CONCLR = 1<<si_bit;  //CLEARING THE SI FLAG BIT
	while(((I2CONSET>>si_bit)&1)==0);
	return I2DAT;
}
	
