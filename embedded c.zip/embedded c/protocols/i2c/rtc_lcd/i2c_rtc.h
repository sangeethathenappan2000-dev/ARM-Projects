			 
#ifndef __I2C_EEPROM_H__

#define __I2C_EEPROM_H__


void i2c_rtc_write(u8,u8,u8);

u8   i2c_rtc_read(u8,u8);




#endif