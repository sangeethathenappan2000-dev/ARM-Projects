#include<lpc21xx.h>

#define STA_BIT	 5
#define STO_BIT	 4
#define SI_BIT	 3
#define cclk 60000000
#define pclk cclk/4
#define i2c_speed 100000
#define LOAD (pclk/i2c_speed)/2
#define I2C_EN 1<<6

void i2c_init()
{
	PINSEL0|=0x50;
	I2SCLL=LOAD;
	I2SCLH=LOAD;
	I2CONSET=I2C_EN;

}

void i2c_start()
{
	I2CONSET=1<<STA_BIT;
	while(((I2CONSET>>SI_BIT)&1)==0);
	I2CONCLR=1<<STA_BIT;
}

void i2c_stop()
{
	I2CONSET=1<<STO_BIT;
	I2CONCLR=1<<SI_BIT;
}

void i2c_restart()
{  I2CONSET=1<<STA_BIT;
   	I2CONCLR=1<<SI_BIT;
	while(((I2CONSET>>SI_BIT)&1)==0);
	I2CONCLR=1<<STA_BIT;
	
}

void i2c_write(unsigned char  data)
{
	I2DAT=data;
	I2CONCLR=1<<SI_BIT;
	while(((I2CONSET>>SI_BIT)&1)==0);
}

unsigned char  i2c_nack()
{
 	I2CONSET=0X00;
	I2CONCLR=1<<SI_BIT;
	while(((I2CONSET>>SI_BIT)&1)==0);
	return I2DAT;

}

