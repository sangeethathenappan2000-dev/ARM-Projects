
#include "eeprom.c"

#define slave_addr 0x50
#define data_addr 0x00
int main()
{	
	unsigned char  ch,data='A';
	i2c_init();
	lcd_init();
	i2c_eeprom_write(slave_addr,data_addr,data);
	ch=i2c_eeprom_read(slave_addr,data_addr);

	delay_ms(100);
	lcd_command(0x80);
	lcd_data(ch);
}


