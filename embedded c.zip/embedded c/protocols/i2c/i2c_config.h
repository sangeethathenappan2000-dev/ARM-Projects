
//functrion decalration for i2c init()

#include "typedefs.h"

void i2c_init(void);
void i2c_write(u8 );
void i2c_start(void);
void i2c_restart(void) ;
void i2c_stop(void);
void noack(void);