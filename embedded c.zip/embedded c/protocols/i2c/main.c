//maindriver for I2C
#include<lpc21xx.h>

#include "macro_define.h"
#include "i2c_config.h"
#include "typedefs.h"
#include "i2c_eeprom.h"
#include "lcd.h"
#include "delay.h"

int main()
{
	u8 ch;
	u8 data='A';

	IODIR1=led1|led2;

	i2c_init();

	i2c_eeprom_write(slave_addr,data_addr,data);
	ch=i2c_eeprom_read(slave_addr,data_addr);
	 delay_ms(100);

	lcd_init();
	lcd_data(ch);

}
