#include "i2c.c"
#include "4bit.h"

void i2c_eeprom_write(unsigned char slave, unsigned char  data_addr, unsigned char  data)
{
	i2c_start();
	i2c_write(slave<<1);
	i2c_write(data_addr);
	i2c_write(data);
	i2c_stop();
	delay_ms(10);
}

unsigned char  i2c_eeprom_read(unsigned char  slave, unsigned char  data_addr)
{	
	unsigned char  dat;
	i2c_start();
	i2c_write(slave<<1);
	i2c_write(data_addr);
	i2c_restart();
	i2c_write((slave<<1)|1);
	dat=i2c_nack();
	i2c_stop();
	return dat;

}
