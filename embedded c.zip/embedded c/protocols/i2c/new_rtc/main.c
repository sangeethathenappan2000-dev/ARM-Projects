#include "eeprom.c"

int main()
{
	unsigned char sec,min,hour;

	lcd_init();
	i2c_init();

	i2c_eeprom_write(0x68,0x00,0x00);
	i2c_eeprom_write(0x68,0x01,0x21);
   i2c_eeprom_write(0x68,0x02,0x04);

	while(1)
	{
	lcd_command(0x80);
	hour=i2c_eeprom_read(0x68,0x02);
	lcd_data((hour/16)+48);
	lcd_data((hour%16)+48);
	lcd_data(':');
	min=i2c_eeprom_read(0x68,0x01);
	lcd_data((min/16)+48);
	lcd_data((min%16)+48);
	lcd_data(':');
	sec=i2c_eeprom_read(0x68,0x00);
 	lcd_data((sec/16)+48);
    lcd_data((sec%16)+48);

	
	}
}

