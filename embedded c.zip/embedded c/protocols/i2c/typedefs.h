
typedef unsigned int u32;
typedef unsigned char u8;

