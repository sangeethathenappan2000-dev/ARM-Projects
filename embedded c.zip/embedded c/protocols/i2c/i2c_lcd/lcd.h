
#define lcd_d 0xff
#define rs 1<<8
#define en 1<<9

void lcd_command(u8 cmd)
{
	IOPIN0=((IOPIN0&0XFFFFFF00)|cmd);
	IOCLR0=rs;
	IOSET0=en;
	delay_ms(2);
	IOCLR0=en;
}

void lcd_data(u8 data)
{
	IOPIN0=((IOPIN0&0XFFFFFF00)|data);
	IOSET0=rs;
	IOSET0=en;
	delay_ms(2);
	IOCLR0=en;
}

void lcd_init()
{
  lcd_command(0x01);
  lcd_command(0x02);
  lcd_command(0x0c);
  lcd_command(0x38);
 }


