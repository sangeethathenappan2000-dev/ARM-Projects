typedef unsigned char u8;


void init_i2c(void);

void i2c_start(void);

void i2c_stop(void);

void i2c_restart(void);

void i2c_write(u8);

u8   i2c_read(void);

u8 i2c_nack(void);

#define cclk 60000000
#define pclk cclk/4
#define i2c_speed 100000
#define load_val (pclk/i2c_speed)/2
#define I2C_en 1<<6
#define STA_BIT 5
#define STO_BIT 4
#define SI_FLAG 3


void i2c_init()
{
	PINSEL0|=0x50;	//p0.2 and p0.3 as SCL and SDA
	I2SCLL=load_val; //I2C speed as 100kbps
	I2SCLH=load_val;
	I2CONSET=I2C_en;	 //enabling i2c
}

void i2c_start()
{
	I2CONSET=1<<STA_BIT; //setting start condition
	while(((I2CONSET>>SI_FLAG)&1)==0); //waiting until si flag is rasied
	I2CONCLR=1<<STA_BIT;			 //clearing the sta bit
}

void i2c_stop()
{
	I2CONSET=1<<STO_BIT; //setting stop condition

	I2CONCLR=1<<SI_FLAG; // clearing the si flag previous status

}

void i2c_restart()
{
	// start condition

	I2CONSET=1<<STA_BIT;

	//clr SI_BIT

	I2CONCLR=1<<SI_FLAG;

	//wait for SI bit status

	while(((I2CONSET>>SI_FLAG)&1)==0);

	// clear start condition

	I2CONCLR=1<<STA_BIT;			 //clearing the sta bit
}

void i2c_write(u8 wBytes)
{
	I2DAT=wBytes;	//writing the data on I2DAT register
	I2CONCLR=1<<SI_FLAG;   //clearing the previous SI flag
	while(((I2CONSET>>SI_FLAG)&1)==0); //waiting until SI flag is set
}

u8 i2c_nack()
{
	I2CONSET = 0x00; //Assert Not of Ack

    I2CONCLR = 1<<SI_FLAG;  //CLEARING THE SI FLAG BIT

	while(((I2CONSET>>SI_FLAG)&1)==0);

	return I2DAT;
}
	