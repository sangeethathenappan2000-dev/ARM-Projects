#include "i2c_eeprom.c"

#include "4bitmode.h"

#define led1 1<<17
#define led2 1<<19

#define slave_addr 0x50
#define word_addr 0x00

int main()
{	u8 ch;

	lcd_init();
	i2c_init();
	IODIR0 |= led1|led2;
	IOSET0 |= led1|led2;

	i2c_eeprom_write(slave_addr,word_addr,'A');
	ch=i2c_eeprom_read(slave_addr,word_addr);

	/*if(ch=='A')
	{
	IOCLR0=led1;
	delay_ms(1000);
	}
	else
	{
	IOCLR0=led2;
	 delay_ms(1000);
	 }	*/

	lcd_command(0x80);
	lcd_data(ch);
	while(1);

}