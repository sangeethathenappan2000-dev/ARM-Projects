#include "delay.h"
#include "i2c.c"
typedef unsigned char u8;

void i2c_eeprom_write(u8,u8,u8);

unsigned char i2c_eeprom_read(u8,u8);


void i2c_eeprom_write(u8 slave,u8 word,u8 data)
{
	i2c_start();	//start condition
	i2c_write(slave<<1); //transmit slave address with write bit 0
	i2c_write(word); //transmit data word addr
	i2c_write(data); //transmit 8bit data
	i2c_stop();	   //stop condition
	delay_ms(10);  // delay for eeprom to write into non voltaile memory
}

u8 i2c_eeprom_read(u8 slave, u8 word)
{	u8 ch;
	i2c_start();	//start condition
	i2c_write(slave<<1); //transmit slave address
	i2c_write(word); //transmit data word addr
	i2c_restart(); //restart condition 
	i2c_write((slave<<1)|1); //transmit slave address with read bit 1
	ch= i2c_nack();	  //storing rceived data
	i2c_stop(); //stop condition
	return ch;
}



	
