//EEPROM WRITE AND READ FUNCTIONS

#include<lpc21xx.h>
#include "delay.h"
#include "i2c_config.h"
#include "i2c_eeprom.h"
#include "macro_define.h"
#include "typedefs.h"


void i2c_eeprom_write(u8 slave_addr,u8 data_addr,u8 data)
{
	i2c_start();
	i2c_write(slave_addr<<1);
	i2c_write(data_addr);
	i2c_write(data);  
	i2c_stop();
	delay_ms(10);
}

u8 i2c_eeprom_read(u8 slave_addr,u8 data_addr)
{	u8 dat;
	i2c_start();
	i2c_write(slave_addr<<1);
	i2c_write(data_addr);
	i2c_restart();
	i2c_write((slave_addr<<1)|1);
	dat=i2c_nack();

	return dat;

}
