
//function declarations for eeprom's 

#include "typedefs.h"

void i2c_eeprom_write(u8 ,u8 ,u8 );

unsigned char i2c_eeprom_read(u8 ,u8 );