//macros definitions

#define led1 1<<17
#define led2 1<<18

//macros for addresses
#define slave_addr 0x50
#define data_addr 0x00

//macros for init()
#define cclk 60000000
#define pclk cclk/4
#define i2c_speed 100000
#define load_val (pcclk/i2c_speed)/2

//macros for i2conset register bits
#define si_flag 3
#define sta 1<<5
#define sto 1<<4

