//configuration functions for i2c

#include<lpc21xx.h>
#include "macro_define.h"

void i2c_init()
{
	PINSEL0=0X50;
	I2SCLL=	load_val;
	I2SCLH= load_val;
	I2CONSET=1<<i2_en;

}

void i2c_write(u8 writeByte)
{
	I2DAT=writeByte;
	I2CONCLR=1<<si_flag;
	while(((I2CONSET>>si_flag)&1)==0);

}

void i2c_start()
{
	I2C_ONSET=sta;
	while(((I2CONSET>>si_flag)&1)==0);
	I2CONCLR=sta;
}

void i2c_restart()
{
	I2CONSET=sta;
	I2CONCLR=1<<si_flag;
	while(((I2CONSET>>si_flag)&1)==0);
	I2CONCLR=sta;
}

void i2c_stop()
{
	I2CONSET=sto;
	I2CONCLR=1<<si_flag;
	while(((I2CONSET>>si_flag)&1)==0);
	I2CONCLR=sto;
}

void noack()
{
	I2CONSET=0X00;
	I2CONCLR=1<<si_flag;
	while(((I2CONSET>>si_flag)&1)==0);
	return I2DAT;

}




