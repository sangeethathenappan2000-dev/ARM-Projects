typedef unsigned char u8;
typedef unsigned int u32;

