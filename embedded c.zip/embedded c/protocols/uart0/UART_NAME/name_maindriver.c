void uart_config(void);
void uart_tx(unsigned char);
void uart_str(unsigned char*);

int main()
{
uart_config();
while(1)
{
uart_str("SANGEETHA");
	}
}
