   #include<lpc21xx.h>

   #define THRE 5
   #define RDR 0

   void uart_config()
   {
   PINSEL0|=0X05; //0.0 AND 0.1 AS TXD AND RXD
   U0LCR=0X83;    //DLAB --> 1 TO ACCESS DLL AND DLM AND 8N1 FRAME
   U0DLL=97; 		//BAUD RATE AS 9600
   U0LCR=0X03;		//DLAB AS 0 TO ACCESS THR AND RDR
   }

   void uart_tx(unsigned char ch)
   {
   U0THR=ch;
   while(((U0LSR>>THRE)&1)==0);
   }

   void uart_str(unsigned char *s)
   {
   while(*s)
   {
   uart_tx(*s++);
   }
   }
