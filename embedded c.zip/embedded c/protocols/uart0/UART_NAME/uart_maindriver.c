void uart_config(void);
void uart_tx(unsigned char);

int main()
{
	unsigned char ch='a';
	
	uart_config();
	while(1)
	{
	while(ch<='z')
	{
	uart_tx(ch++);
	}
	}
}
