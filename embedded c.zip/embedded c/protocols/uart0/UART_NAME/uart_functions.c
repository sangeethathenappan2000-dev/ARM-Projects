#include<lpc21xx.h>

#define THRE 5
#define RDR 0

void uart_config()
{
PINSEL0|=0X05;
U0LCR=0X83;		//DLAB AS 1 -->TO ACCESS DLL AND DLM
UODLL=97;
