 #include<lpc21xx.h>
#include "4_bit_lcd.h" 
 #define THRE 5
 #define RDR 0

typedef unsigned char u8;


uart0_config()
{
 	PINSEL0|=0x05;
	U0LCR=0x83;
	U0DLL=97;
	U0LCR=0x03;

}

u8 uart0_rx()
{	
	while(!((U0LSR>>RDR)&1));
	return U0RBR;
}

unsigned char to_opposite_case(unsigned char s)
{
	return s^32;

}

void uart0_tx(u8 ch)
{
U0THR=ch;
while(((U0LSR>>THRE)&1)==0);
}


int main()
{	unsigned char rxbyte;
	u8 p;
 	uart0_config();
	LCD_INIT();	
	LCD_COMMAND(0x80);
	LCD_STR("recived:");
	while(1)
	{	     
	 	rxbyte=uart0_rx();
		LCD_COMMAND(0X01);
		LCD_COMMAND(0x80);
		LCD_STR("received:");
		LCD_COMMAND(0xc0);
		LCD_DATA(rxbyte);
		p=to_opposite_case(rxbyte);
		uart0_tx(p);
		delay_ms(1000);
	}
}
