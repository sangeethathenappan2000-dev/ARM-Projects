#include "4bitmode.h"


#define thre 5
#define rbr 0

#define led 1<<17



void uart_init()
{
PINSEL0|=0x05;
U0LCR=0X83;
U0DLL=97;
U0LCR=0X03;
}

void uart_tx(u8 txByte)
{
U0THR=txByte;
while(((U0LSR>>thre)&1)==0);
}

u8 uart_rx()
{u8 rxByte;
while(((U0LSR>>rbr)&1)==0);
rxByte=U0RBR;
return rxByte;
}

void uart_str(u8* s)
{
while(*s)
{
uart_tx(*s++);
}
}

int main()
{	u8 ch;
	IODIR0|=led;
	uart_init();
	lcd_init();
	IOSET0=led;

	//uart_str("AT");
	//uart_str("AT+UART=9600,1,0");
	lcd_command(0x01);

	while(1)
	{
		ch=uart_rx();
		if(ch=='1')
		{
			IOCLR0=led;
			lcd_command(0x80);
			lcd_str("LED  ON");
			uart_str("LED ON\n\r");
			}
			else if(ch=='0') 
			{
			IOSET0=led;
			lcd_command(0x80);
			lcd_str("LED OFF");
			uart_str("LED OFF\n\r");
			}
			}
	}

