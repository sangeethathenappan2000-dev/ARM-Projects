 #include<lpc21xx.h>
 #include "4_bit_lcd.h" 
 #define THRE 5
 #define RDR 0

typedef unsigned char u8;


uart0_config()
{
 	PINSEL0|=0x05;
	U0LCR=0x83;
	U0DLL=97;
	U0LCR=0x03;

}

u8 uart0_rx()
{	
	while(!((U0LSR>>RDR)&1));
	return U0RBR;
}

void uart0_tx(u8 ch)
{
U0THR=ch;
while(((U0LSR>>THRE)&1)==0);
}


void uart0_str(unsigned char* s)
{
	while(*s)
	{
	uart0_tx(*s++);
	}

}

int main()
{	unsigned char rxbyte[20],i=0,ch;
 	uart0_config();
	LCD_INIT();
	LCD_COMMAND(0x80);
	LCD_STR("received:");
	while(1)
	{	 while(ch!='\n' || ch!='\r')
	      {	
	 		ch=uart0_rx();
			if(ch=='\n' || ch=='\r')
				 {
				 rxbyte[i]='\0';
				 i=0;
				 ch=0;
				 break;													
				 }
			rxbyte[i++]=ch;

		  }	
		  	
			LCD_COMMAND(0xc0);
			LCD_STR(rxbyte);

			uart0_str(rxbyte);
			//delay_ms(1000);
	}
	}
