#include<lpc21xx.h>
#include "delay.h"
#define THRE 5
#define RDR 0
#define sw 14

typedef unsigned char u8;

void uart_config()
{	PINSEL0|=0X05;
 	U0LCR=0X83;
	U0DLL=97;
	U0LCR=0X03;
	}

void uart_tx(u8 ch)
{
U0THR=ch;
while(((U0LSR>>THRE)&1)==0);
}

void uart_str(u8* s)
{
	while(*s)
		uart_tx(*s++);
	}
int main()
{
	uart_config();
	uart_str("AT\r\n");
	delay_ms(500);
	uart_str("AT+CMGF=1\r\n");
	delay_ms(500);
	uart_str("AT+CMGS=+917010839932\r\n");
	delay_ms(500);
	while(1)
	{
	if(((IOPIN0>>sw)&1)==0)
	{
	uart_str("Hi Meenakshi, your account is credited with Rs. 100000000\n\r\n");
	delay_ms(500);
	break;
	}
	}
	uart_tx(0x1a);

}