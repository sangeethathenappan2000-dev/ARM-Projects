#include<lpc21xx.h>
#include "delay.h"

#define THRE 5
#define RBR 0

#define sw1 14
#define sw2 15
#define sw3 16
#define sw4 17

void uart0_config()
{ 

 PINSEL0|=0X05;
 U0LCR=0X83; //DLAB-1 FOR ACCESSING DLL AND DLM AND CONFIGURE 8N1 FRAME'
 U0DLL=97;  //BAUDRATE AS 9600
 U0LCR=0X03;  //DLAB -0 FOR ACCESING THR AND RDR

}
void uart0_tx(unsigned char ch)
{
	U0THR=ch;
	while(((U0LSR>>THRE)&1)==0);

}

void uart0_str(unsigned char* s)
{
 	while(*s)
	{
	uart0_tx(*s++);
	}
}
	
int main()
{
	uart0_config();
	while(1)
	{
	if(((IOPIN0>>sw1)&1)==0)
		{  delay_ms(100);
			uart0_str("SW1 is pressed");
		}
	else if(((IOPIN0>>sw2)&1)==0)
		{ delay_ms(250);
		uart0_str("SW2 is pressed");
		}
    else if(((IOPIN0>>sw3)&1)==0)                                                                                        	 
		{ delay_ms(250);
		uart0_str("SW3 is pressed");
		}
	else if(((IOPIN0>>sw4)&1)==0)
		{  delay_ms(250);
		uart0_str("SW4 is pressed");
		}
		}
	}




																								                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     