void UART_CONFIG(void);
void UART_TX(unsigned char);

int main()
{
UART_CONFIG();
UART_TX('A');
}

