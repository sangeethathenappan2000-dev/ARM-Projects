#include<lpc21xx.h>

#include "header.h"
#include "can_rx.c"
#include "uart.c"

int main()
{	CAN_MSG m1;
	can_init();
	uart0_init();
	uart0_str("NodeB testing CAN");

	while(1)
	{
		can_rx(&m1);
	   if(m1.rtr==0)
		{
			uart0_str("NODE B received data frame\r\n");
			uart0_tx_hex(m1.id);
			uart0_tx(' ');
			uart0_tx_hex(m1.dlc);
			uart0_tx(' ');
			uart0_tx_hex(m1.aByte);
			uart0_tx(' ');
			uart0_tx_hex(m1.bByte);
			uart0_str("\r\n");
		}
		else
		{
			uart0_str("NODE B received remote frame\r\n");
			uart0_tx_hex(m1.id);
			uart0_tx(' ');
			uart0_tx_hex(m1.dlc);
			uart0_tx(' ');
			uart0_str("\r\n");
		}
	}
}



