//all header file content

#ifndef _defines_
#define _defines_

typedef unsigned char u8;
typedef unsigned int u32;

//typedefs 

typedef struct can_msg			 //can message with id,dlc,rtr
{
	u32 id;
	u32 dlc;
	u32 rtr;
	u32 aByte;
	u32 bByte;
		
}CAN_MSG;

#endif