#include<lpc21xx.h>
#include "header.h"
#include<stdio.h>

uart0_init()
{
 	PINSEL0|=0x05;
	U0LCR=0x83;
	U0DLL=32;
	U0LCR=0x03;

}

u8 uart0_rx()
{	
	while(!((U0LSR>>0)&1));
	return U0RBR;
}

void uart0_tx(u8 ch)
{
U0THR=ch;
while(((U0LSR>>5)&1)==0);
}


void uart0_str(unsigned char* s)
{
	while(*s)
	{
	uart0_tx(*s++);
	}

}

uart0_tx_hex(int num)
{
	char buf[10];
	sprintf(buf,"%x",num);
	uart0_str(buf);
}
