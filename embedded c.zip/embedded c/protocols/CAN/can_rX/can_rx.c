//receiver 
#include "header.h"

void can_init()
{
	PINSEL1|=0x14000;  //p0.22 and p0.23 as Rd and Td
	VPBDIV=1;          // PClk as 60Mhz
	C2MOD= 1;			   //reset mode
	//configurations done in reset mode
	AFMR=0x02; //acceptance filter for receiving all type of messages
	C2BTR=0x001C001D;  //BRP=(PClk/Bit rate *16)
	//return to normal mode for can activities
	C2MOD=0;     //normal mode
}

void can_rx(CAN_MSG * m1)
{
	while((C2GSR&1)==0); // checking status of receive buffer status
	m1->id=C2RID;
	m1->dlc=(C2RFS>>16)&0xf; //getting 16-19 bit values alone
	m1->rtr=(C2RFS>>30)&1;	  // getting rtr value

	if(m1->rtr==0)	   //if data frame
	{
		m1->aByte=C2RDA;
		m1->bByte=C2RDB;
	}
	C2CMR=1<<2;  //free the rceive buffer

}