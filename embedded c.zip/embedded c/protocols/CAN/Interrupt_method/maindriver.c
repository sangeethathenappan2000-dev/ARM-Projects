#include<lpc21xx.h>
#include "can_int.c"


int main()
{	
	can_init();
	can_interrupt_init();
	IODIR0|=LED;

	m2.id=0x01;
	m2.dlc=4;
	m2.rtr=0;
	m2.AByte=0x11223344;

	while(1)
	{
	can_tx(m2);
	delay_sec(1);

	}
}
	