#include<lpc21xx.h>
#include "can_tx.c"


void delay_sec(int s)
{
	T0PR=60000000-1;
	T0TCR=0X01;
	while(T0TC<s);
	T0TCR=0x03;
	T0TCR=0x00;
}

int main()
{
	CAN_MSG m1;
	m1.id=0x001;
	m1.dlc=4;
	m1.rtr=0;
	m1.AByte=0x11223344;

	can_init();

	while(1)
	{
	can_tx(m1);
	delay_sec(10);

	}
}
