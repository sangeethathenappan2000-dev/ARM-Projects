#include "delay.h"

#define seg_d 0xff
#define sw 14
typedef unsigned char u_ch;
u_ch seg_lut[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90};

int main()
{	u_ch count=0;
	IODIR0=seg_d;
	while(1)
	{
	if(((IOPIN0>>sw)&1)==0)
	{
	
	if(count>9)
	{
	count=0;
	}
	count++;
	IOCLR0=seg_d;
	IOSET0=seg_lut[count];
	delay_ms(500);
	}
}

}