	 #include "delay.h"

#define seg_d 0xff
#define seg_1 1<<9
#define seg_2 1<<10
#define SW 14


typedef unsigned char u8;

u8 seg_lut[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90}; //lookup table for digits
u8 dp1=0xff;
u8 dp2=0xff;

void digit_disp(int);
void float_disp(float);

int main()
{
u8 count=0;
IODIR0=seg_d|seg_1|seg_2;

while(1)
{  
   if(((IOPIN0>>SW)&1)==0)
   {
   while(count<=20)
   {
   digit_disp(count++);
   delay_ms(50);

   }
   count=0;
   }
}
}

void digit_disp(int x)
{
   IOCLR0=seg_d;
   IOSET0=seg_lut[x/10];
   IOCLR0=seg_1;
   delay_ms(5);
   IOSET0=seg_1;

   IOCLR0=seg_d;
   IOSET0=seg_lut[x%10];
   IOCLR0=seg_2;
   delay_ms(5);
   IOSET0=seg_2;

}

