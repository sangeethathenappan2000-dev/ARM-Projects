#include "delay.h"

#define seg_d 0xff
typedef unsigned char uch;

uch seg_lut[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90}; 

int main()
{
uch digit=0;
IODIR0=seg_d;
while(digit<10)
{
IOCLR0=seg_d;
IOSET0=seg_lut[digit++];
delay_ms(500);
}
}
