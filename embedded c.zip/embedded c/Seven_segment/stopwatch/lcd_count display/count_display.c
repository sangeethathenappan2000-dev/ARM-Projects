#include "4_bit_lcd.h"

#define sw 14
#define seg_d 0xff
typedef unsigned char u_ch;
u_ch seg_lut[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90};


int main()
{	unsigned char count=0;
	LCD_INIT();
	LCD_COMMAND(0X80);
	LCD_STR("SWITCH PRESS:");
	while(1)
	{LCD_COMMAND(0XC0);
	if(((IOPIN0>>sw)&1)==0)
	{delay_ms(10);
	count++; 
	LCD_INTEGER(count);
	delay_ms(500);
	IOCLR0=seg_d;
	IOSET0=seg_lut[count];
	delay_ms(500);
	if(count>9)
	{
	count=0;
	}

	}
}


}
