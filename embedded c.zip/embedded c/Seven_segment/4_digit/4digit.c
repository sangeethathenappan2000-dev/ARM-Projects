#include "delay.h"

 #define seg_d 0xff
#define seg_1 1<<9
#define seg_2 1<<10
#define seg_3 1<<11
#define seg_4 1<<12


typedef unsigned char u8;

u8 seg_lut[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90}; //lookup table for digits

void digit_disp(int);
void float_disp(float);

int main()
{
	IODIR0=seg_d|seg_1|seg_2|seg_3|seg_4;
	
	while(1)
	{  
	digit_disp(1234);
	}
}

void digit_disp(int x)
{	int temp;
	int div=1000;
	u8 i;
   for(i=0;i<4;i++)
   {  temp=x/div;

   IOCLR0=seg_d;
   IOSET0=seg_lut[temp];
   IOCLR0=(seg_1)<<i;
   delay_ms(5);
   IOSET0=(seg_1)<<i;

   x=x%div;
   div=div/10;
	}
	
}

