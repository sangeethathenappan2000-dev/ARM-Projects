/*2 digit 7 segment display*/

#include "delay.h"

#define seg_d 0xff
#define seg_1 1<<9
#define seg_2 1<<10

typedef unsigned char u8;

u8 seg_lut[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90}; //lookup table for digits
u8 dp1=0xff;
u8 dp2=0xff;

void digit_disp(int);
void float_disp(float);

int main()
{
IODIR0=seg_d|seg_1|seg_2;

while(1)
{  float_disp(2.4);
}
}

/*void digit_disp(int x)
{
   IOCLR0=seg_d;
   IOSET0=seg_lut[x/10];
   IOCLR0=seg_1;
   delay_ms(5);
   IOSET0=seg_1;

   IOCLR0=seg_d;
   IOSET0=seg_lut[x%10];
   IOCLR0=seg_2;
   delay_ms(5);
   IOSET0=seg_2;

}*/

void digit_disp(int x)
{
   IOCLR0=seg_d;
   IOSET0=seg_lut[x/10]&dp1;
   IOCLR0=seg_1;
   delay_ms(5);
   IOSET0=seg_1;

   IOCLR0=seg_d;
   IOSET0=seg_lut[x%10]&dp2;
   IOCLR0=seg_2;
   delay_ms(5);
   IOSET0=seg_2;

}

void float_disp(float f)
{
	int temp=0;
	if((f>=0.0)&& (f<10.0))
	{	dp1=0x7f;
	temp=f*10;
	}
	digit_disp(temp);
}

