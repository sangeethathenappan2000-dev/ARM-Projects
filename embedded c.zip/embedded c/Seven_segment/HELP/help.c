#include "delay.h"

#define seg_d 0xff
#define seg_1 1<<8
#define seg_2 1<<9
#define seg_3 1<<10
#define seg_4 1<<11

unsigned char seg_lut[]={0x89,0x86,0xc7,0x8c};
void display(unsigned char *s)
{

	unsigned char i=0;
	for(i=0;i<4;i++)
	{
		IOCLR0=seg_d;
		IOSET0=seg_lut[i];
		IOCLR0=seg_1<<i;
		delay_ms(5);
		IOSET0=seg_1<<i;
	}
}


int main()
{
	unsigned char i=0;
	IODIR0=seg_d|seg_1|seg_2|seg_3|seg_4;
	while(1)
	{
	display("HELP");
	delay(5);
	
	
	}
}

