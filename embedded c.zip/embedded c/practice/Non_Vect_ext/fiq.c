#include<lpc21xx.h>

#define led 1<<0
void isr(void)__irq
{
	EXTINT=0x01;
	IOCLR0=led;
	IOSET0=led;
	VICVectAddr=0;

}

int main()
{
	PINSEL1=0x01;
	IODIR0=led;
	IOSET0=led;

	VICIntSelect=1<<14;
	EXTMODE=0x00;
	EXTPOLAR=0x00;
	VICIntEnable=1<<14;

	while(1)
	count++;
}
