#include<lpc21xx.h>
#define led 1<<0

void non_isr(void) __irq
{
	EXTINT=0x02;
	IOCLR0=led;
	IOSET0=led;
	VICVectAddr=0;
}

int main()
{	int count=0;
	IODIR0=led;
	PINSEL0=1<<29;

	VICIntSelect=0;
	VICDefVectAddr=(int)non_isr;
	EXTMODE=0x02;
	EXTPOLAR=0x02;

	VICIntEnable=1<<15;
	while(1)
	{
	count++;
	}

	}