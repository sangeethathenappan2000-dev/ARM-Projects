#include<lpc21xx.h>

void uart_isr(void) __irq
{	char rx_byte;
	char temp=U0IIR;
	if(temp==0x04)
	{
	rx_byte=U0RBR;
	U0THR=rx_byte;
	}
	VICVectAddr=0;
}

void uart_init()
{
	PINSEL0|=0x05;
	U0LCR=0x83;
	U0DLL=97;
	U0LCR=0x03;
}

void uart_interrupt()
{
	VICIntSelect=0;
	VICVectCntl0=1<<5|6;
	VICVectAddr0=(int)uart_isr;
	VICIntEnable=1<<6;
	U0IER=1<<0|1<<1;
}

int main()
{	int count=0;
	uart_init();
	uart_interrupt();
	while(1)
	{
	 count++;
	}
}

