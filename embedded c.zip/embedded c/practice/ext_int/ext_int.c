#include<lpc21xx.h>

#define led 1<<17

void eint_isr(void)__irq
{
   EXTINT=0x01;
   IOCLR0=led;
   IOSET0=led;
   VICVectAddr=0;

}

int main()
{ int count=0;
  PINSEL1=0x01;
  IODIR0=led;

  VICIntSelect=0;
  VICVectCntl0=1<<5|14;
  VICVectAddr0=(int)eint_isr;

  EXTMODE=0x01;
  EXTPOLAR=0x00;

  VICIntEnable=1<<14;

  while(1)
  {
  count++;
  }
  }
