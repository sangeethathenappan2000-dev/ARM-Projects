#include<lpc21xx.h>

#define seg_d 0xff
#define seg_1 1<<8
#define seg_2 1<<9
#define seg_3 1<<10
#define seg_4 1<<11

int sec=0,mins=0;
int seg_lut[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90};
int dp=0x7f;

void  delay_ms(int ms)
{
	T0PR=15000000-1;
	T0TCR=0x01;
	while(T0TC<ms);
	T0TCR=0x03;
	T0TCR=0x00;
}

void display()
{	   int i;
		for(i=0;i<50;i++)
		{
			IOCLR0=seg_d;
			IOSET0=seg_lut[mins/10];
			 IOCLR0=seg_1;
			delay_ms(2);
			IOSET0=seg_1;

			IOCLR0=seg_d;
			IOSET0=seg_lut[mins%10]&dp;
			IOCLR0=seg_2;
			delay_ms(2);
			IOSET0=seg_2;

			IOCLR0=seg_d;
			IOSET0=seg_lut[sec/10];
			IOCLR0=seg_3;
			delay_ms(2);
			IOSET0=seg_3;

			IOCLR0=seg_d;
			IOSET0=seg_lut[sec%10];
			IOCLR0=seg_4;
			delay_ms(2);
			IOSET0=seg_4;
		}
 }
int main()
{
	IODIR0|=seg_d|seg_1|seg_2|seg_3|seg_4;
	while(1)
	{ display();
		sec++;
		if(sec>59)
		{
		mins++;
		sec=0;
		}
	}
	}
