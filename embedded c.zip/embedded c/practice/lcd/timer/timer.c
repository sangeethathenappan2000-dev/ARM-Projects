#include<lpc21xx.h>
#include "lcd.h"

int main()
{
	int sec=0,min=0;
	lcd_init();

	while(1)
	{	lcd_command(0x80);

		lcd_data(min/10+48);
		lcd_data(min%10+48);
		lcd_data(':');
		lcd_data(sec/10+48);
		lcd_data(sec%10+48);
		delay_ms(1000);
		sec++;
		if(sec>59)
		{
			min++;
			sec=0;
		}
	}
}