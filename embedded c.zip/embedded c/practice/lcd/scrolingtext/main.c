#include<lpc21xx.h>
#include"4bitmode.c"
#include<string.h>

int main()
{	char *s;
	int count=0;
	int len,cmd,len1;
	lcd_init();
	s="embedded systems";
	len=strlen(s);
	while(1)
	{
		count=0,len1=len;
		for(cmd=0x80;cmd<0x8f;cmd++)
		{
			lcd_command(cmd);
			lcd_str(s);
			count++;
			if(count>(16-len))
			{	lcd_command(0x80);
			len1--;
			lcd_str(s+len1);
			}
			delay(500);
		}
	}
}