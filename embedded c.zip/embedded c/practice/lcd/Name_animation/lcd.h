#include "delay.h"

#define LCD_D 0xff
#define RS 1<<8
#define EN 1<<9

typedef unsigned char u8;

void lcd_command(u8 cmd)
{	
	IOPIN0=(IOPIN0&0XFFFFFF00)|cmd;
	IOCLR0=RS;
	IOSET0=EN;
	delay_ms(2);
	IOCLR0=EN;

}

void lcd_data(u8 data)
{	
	IOPIN0=(IOPIN0&0XFFFFFF00)|data;
	IOSET0=RS;
	IOSET0=EN;
	delay_ms(2);
	IOCLR0=EN;

}
void lcd_str(u8* s)
{
	while(*s)
		lcd_data(*s++);
}

void lcd_init()
{
	IODIR0=LCD_D|RS|EN;

	lcd_command(0x01);
	lcd_command(0x02);
	lcd_command(0x0c);
	lcd_command(0x38);
}
