#include "lcd.h"
#include<string.h>

int main()
{
  	u8 i;
	int len=strlen("SANGEETHA");
	lcd_init();
	while(1)
	{
		
		for(i=0;i<=(16-len);i++)
		{
				  lcd_command((0x80)|i);
				  lcd_str("SANGEETHA");
				  delay_ms(500);
				  lcd_command(0x01);
		}
		for(;i>=0;i--)
		{
				  lcd_command(0x80|i);
				  lcd_str("SANGEETHA");
				  delay_ms(500);
				  lcd_command(0x01);
		} 

	}

                                                                                                       

}