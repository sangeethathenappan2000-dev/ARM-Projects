#include "delay.h"

#define lcd_d 0xff
#define rs 1<<8
#define en 1<<9

typedef unsigned char u8;

void lcd_command(u8 cmd)
{
IOPIN0=((IOPIN0&0xffffff00)|cmd);
IOCLR0=rs; // select command register
IOSET0=en; //latch data from data pins to lcd
delay_ms(2); //	internal operation
IOCLR0=en;
}

void lcd_data(u8 d)
{
IOPIN0=((IOPIN0&0xffffff00)|d);
IOSET0=rs; // select data register
IOSET0=en; //latch data from data pins to lcd
delay_ms(2); //	internal operation
IOCLR0=en;
}


void lcd_init()
{
	IODIR0=lcd_d|en|rs;
	lcd_command(0x01); //clear lcd
	lcd_command(0x02); //cursor to home position
	lcd_command(0x0c); //display on cursor off
	lcd_command(0x38); //8bit lcd mode
}
void lcd_str(u8* s)
{
	while(*s)
	lcd_data(*s++);
}
int main()
{	  u8 i=0 ;

	lcd_init();
	lcd_command(0x80);
	while(1)
	{	lcd_command(0x80|i);
		lcd_str("Welcome");
		delay(1);
		lcd_command(0x01);
		i++;
		}
		}