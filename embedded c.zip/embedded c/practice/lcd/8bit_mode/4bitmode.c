#include<lpc21xx.h>

#define lcd_d 0xf //1.20,21,22,23
#define rs 	1<<17	  //1.17
#define rw 	1<<18	  //1.18
#define en	1<<19	  //1.19

void delay(int ms)
{
	T0PR=15000-1;
	T0TCR=0x01;
	while(T0TC<ms);
	T0TCR=0x03;
	T0TCR=0x00;
}

void lcd_command(unsigned char cmd)
{
	IOCLR1=lcd_d;
	IOSET1=(cmd&0xf0)<<16; //extract upper nibble 
	IOCLR1=rs;
	IOSET1=en;
	delay(2);
	IOCLR1=en;

	IOCLR1=lcd_d;
	IOSET1=(cmd&0x0f)<<20; //extract lower nibble 
	IOCLR1=rs;
	IOSET1=en;
	delay(2);
	IOCLR1=en;
}

void lcd_data(unsigned char data)
{
	IOCLR1=lcd_d;
	IOSET1=(data&0xf0)<<16; //extract upper nibble 
	IOSET1=rs;
	IOSET1=en;
	delay(2);
	IOCLR1=en;

	IOCLR1=lcd_d;
	IOSET1=(data&0x0f)<<20; //extract lower nibble 
	IOSET1=rs;
	IOSET1=en;
	delay(2);
	IOCLR1=en;
}

void lcd_init()
{
	IODIR1|=(lcd_d|rs|en|rw);
	IOCLR1=rw;

	lcd_command(0x01);
	lcd_command(0x02);
	lcd_command(0x0c);
	lcd_command(0x28);
}

void lcd_str(unsigned char * str)
{
	while(*s)
	lcd_data(*s++);
}

void lcd_integer(unsigned int n)
{
	unsigned int a[5],i=0;
	if(n==0)
	lcd_data('0');
	else
	{
	if(n<0)
	n=-n;

	while(n>0)
	{
		a[i++]=n%10;
		n/=10;
	}

	for(--i;i<5;i++)
	{
		lcd_data(a[i]+48);
	}
	}
}

void lcd_float(float f)
{
	int n=f;
	lcd_integer(n);
	lcd_data('.');
	lcd_integer((f-n)*100);
}

int main()
{
	lcd_init();
	lcd_command(0x80);
	lcd_data('a');
	lcd_integer(1234);
	lcd_str("hi");
	lcd_float(3.14);
}

