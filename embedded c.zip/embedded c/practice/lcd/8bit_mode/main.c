#include<lpc21xx.h>

#define lcd_d 0xff
#define rs 1<<8
#define en 1<<9

void delay(int ms)
{
	T0PR=15000-1;
	T0TCR=0X01;
	while(T0TC<ms);
	T0TCR=0X03;
	T0TCR=0X00;
}

void lcd_command(unsigned char cmd)
{
	IOPIN0=(IOPIN0&0xffffff00)|cmd;
	IOCLR0=rs;
	IOSET0=en;
	delay(2);
	IOCLR0=en;
}

void lcd_data(unsigned char data)
{
	IOPIN0=(IOPIN0&0xffffff00)|data;
	IOSET0=rs;
	IOSET0=en;
	delay(2);
	IOCLR0=en;
}

void lcd_init()
{	
	IODIR0|=(lcd_d|rs|en);
	lcd_command(0x01);
	lcd_command(0x02);
	lcd_command(0x0c);
	lcd_command(0x38);
}

int main()
{
	lcd_init();
	lcd_command(0x80);
	lcd_data('A');
}
