#include "delay.h"

#define lcd_d 0xff
#define rs 1<<8
#define en 1<<9

typedef unsigned char u8;

void lcd_command(u8 cmd)
{
   IOPIN0=(IOPIN0&0xffffff00)|cmd;  //preserving the IOPIN status
   IOCLR0=rs;   //select command register
   IOSET0=en;  	//latch data from data pin to lcd
   delay_ms(2);	 //internal operation
   IOCLR0=en;

}

void lcd_data(u8 d)
{
   IOPIN0=(IOPIN0&0xffffff00)|d;  //preserving the IOPIN status
   IOSET0=rs;   //select data register
   IOSET0=en;  	//latch data from data pin to lcd
   delay_ms(2);	 //internal operation
   IOCLR0=en;
}
void lcd_init()
{
 IODIR0=lcd_d|rs|en;
 lcd_command(0x01); //clear tthe display
 lcd_command(0x02); //cursor to home position
 lcd_command(0x0c); //display on cursor off
 lcd_command(0x38);	// 8bit mode
}

int main()
{  u8 count=0;
  lcd_init();
  lcd_command(0x80);
  while(count<5)
  {	count++;
  	lcd_data('A');
	delay(1);
	lcd_command(0x01);
	delay(1);
	}
	lcd_data('A');

}