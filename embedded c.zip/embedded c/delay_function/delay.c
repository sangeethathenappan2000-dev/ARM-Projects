#include<lpc21xx.h>
typedef unsigned int u_int ;
void delay(u_int second)
{

	T0PR=15000000-1;
	T0TCR=0x01;
	while(T0TC<second);
	T0TCR=0x03;
	T0TCR=0x00;
	
	}

	int main()
	{
	PINSEL0=0X00;
	IODIR0=0X01;
	while(1)
	{IOCLR0=0X01;
	delay(5);
	IOSET0=0X01;
	  delay(5);
	}
	}
