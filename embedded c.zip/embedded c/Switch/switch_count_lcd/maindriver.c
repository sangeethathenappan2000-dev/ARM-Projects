#include "lcd.h"

#define sw 14

typedef unsigned char u8;

int main()
{	u8 count=0;
	LCD_INIT();
	LCD_COMMAND(0X80);
	LCD_STR("PRESS COUNT -");
	while(1)
	{
	if(((IOPIN0>>sw)&1)==0)
	{	delay_ms(250);
		
		count++;
		LCD_COMMAND(0XC0);
		LCD_INTEGER(count);

	}


	}

}
