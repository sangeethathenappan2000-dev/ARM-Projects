#include "delay.h"
#define sw 14
typedef unsigned char u8;

int main()
{    
	 u8 sw_count=0;
	 u8 input=0;

	 IODIR0=0XFF;
	 IOSET0=0XFF;
	 while(1)
	 {
	 if(((IOPIN0>>sw)&1)==0)
	 {	++sw_count;
	 	input|=(1<<(sw_count-1));
		IOCLR0=input;
		delay(1);
		//IOSET0=input;
		//delay(1);
		if(sw_count>=8)
		{
		sw_count=0;
		input=0;
		IOSET0=0XFF;
		}
}

}
}