#include"lcd.h"

void my_str(unsigned char* );

int main()
{
	LCD_INIT();
	while(1)
	{
	LCD_COMMAND(0X80);
	LCD_STR("SANGEETHA");
	LCD_COMMAND(0XC0);
	LCD_STR("EMBEDDEDENGINEER");
}
}

void my_str(unsigned char* s)
{
	while(*s)
	{
	LCD_DATA(*s++);
	}
}
