
typedef unsigned char uc;

#define LCD_D 0xff<<0
#define RS 1<<8
#define E 1<<9

void delay_ms(int ms)
{
	T0PR=15000-1;
	T0TCR=0x01;
	while(T0TC<ms);
	T0TCR=0x03;
	T0TCR=0x00;
}

void lcd_command(unsigned char cmd)
{
	 IOPIN0=(IOPIN0&0xFFFFFF00)|cmd;
	 IOCLR0=RS; //SELECT COMMAND REGISTER
	 IOSET0=E;
	delay_ms(2); 
	IOCLR0=E;
	                                                
}

void lcd_data(unsigned char d)
{
	  IOPIN0=(IOPIN0&0xFFFFFF00)|d;
	 IOSET0=RS; //SELECT DATA REGISTER
	 IOSET0=E;
	delay_ms(2); 
	IOCLR0=E;
}
void lcd_str(unsigned char* S)
{  int COUNT=0;
	while(*S)
	{	if(COUNT==16)
			lcd_command(0XC0);
		lcd_data(*S++); 
		COUNT++;
	}
}

void lcd_integer(int n)
{		uc a[5];
		int i=0;

		if(n==0)
		{	lcd_data('0'); }
		else
		{
			if(n<0)
				{
				lcd_data('-');
				n=-n;
				}
			while(n>0)
			{
			a[i++]=n%10;
			n=n/10;
			}
			for(--i;i>=0;i--)
			{	lcd_data(a[i]+48); }
		}

}

void cgram_write(unsigned char nBytes,char *lut)
{
	unsigned char i;
	for(i=0;i<nBytes;i++)
		lcd_data(lut[i]);
}
	
void lcd_init()
{
	   IODIR0=LCD_D|RS|E;
	   lcd_command(0X01);
	   lcd_command(0X02);
	   lcd_command(0X0C);
	   lcd_command(0X38);

}