#include "lcd.h"
#define LED1 1<<16
#define LED2 1<<17
#define SW1 14
#define SW2 15


const unsigned char cgram_lut[]={0x17,0x14,0x14,0x1f,0x05,0x05,0x1d,0x00};

int main()
{
	LCD_INIT();
	CGRAM_WRITE(16,cgram_lut);
	
	if(((IOPIN0>>SW1)&1)==0)
	{
	i=10;
	while(i--)
	{
	IOCLR0=LED1;
	LCD_COMMAND(0X80);
	LCD_DATA(0);
	delay(1);
	IOSET0=LED1;
	//while(((IOPIN0>>SW1)&1)==0);
	LCD_COMMAND(0X01);
	}
	}
	else if(((IOPIN0>>SW2)&1)==0)
	{
	  i=10;
	while(i--)
	{
	IOCLR0=LED2;
	LCD_COMMAND(0X8F);
	LCD_DATA(1);
	delay(1);
	IOSET0=LED2;
	//while(((IOPIN0>>SW1)&1)==0);
	LCD_COMMAND(0X01);
	
	
	}
}
 }
