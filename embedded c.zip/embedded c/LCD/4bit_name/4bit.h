#include<lpc21xx.h>

#define lcd_d 0xf<<20
#define rs 	1<<17
#define rw 1<<18
#define en 1<<19
typedef unsigned char u8;

void delay_ms(int ms)
{
 	T0PR=15000-1;
	T0TCR=0X01;
	while(T0TC<ms);
	T0TCR=0X03;
	T0TCR=0X00;

}
void lcd_command(u8 cmd)
{
	IOCLR1=lcd_d;
	IOSET1=	(cmd&0XF0)<<16;
	IOCLR1=rs;
	IOSET1=en;
	delay_ms(2);
	IOCLR1=en;

	IOCLR1=lcd_d;
	IOSET1=	(cmd&0X0F)<<20;
	IOCLR1=rs;
	IOSET1=en;
	delay_ms(2);
	IOCLR1=en;		
}

void lcd_data(u8 data)
{  IOCLR1=lcd_d;
	IOSET1=	(data&0XF0)<<16;
	IOSET1=rs;
	IOSET1=en;
	delay_ms(2);
	IOCLR1=en;

	IOCLR1=lcd_d;
	IOSET1=	(data&0X0F)<<20;
	IOSET1=rs;
	IOSET1=en;
	delay_ms(2);
	IOCLR1=en;	

}
void lcd_str(u8* s)
{
	while(*s)
	{
	lcd_data(*s++);
	}
}

void lcd_init()
{ IODIR1=lcd_d|rs|rw|en;
   IOCLR1=rw;

lcd_command(0x01);
lcd_command(0x02);
lcd_command(0x0c);
lcd_command(0x28);
}



