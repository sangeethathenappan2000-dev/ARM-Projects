#include<LPC21XX.H>

typedef unsigned int u32;

void delay_ms(u32);
void delay_us(u32);
void delay(u32);
				
void delay_ms(u32 ms)	  //DELAY FUNCTION FOR PRODUCING MILLISECOND DELAY
{
	T0PR=15000-1;
	T0TCR=0X01;
	while(T0TC<ms);
	T0TCR=0X03;
	T0TCR=0X00;
	
}

void delay_us(u32 us)  // DELAY FUNCTION FOR PRODUCING MICROSECOND DELAY
{

	T0PR=15-1;
	T0TCR=0X01;
	while(T0TC<us);
	T0TCR=0X03;
	T0TCR=0X00;

}

void delay(u32 seconds)	   // DELAY FOR PRODUCING SECOND DELAY
{

	T0PR=15000000-1;
	T0TCR=0x01;
	while(T0TC<seconds);
	T0TCR=0x03;
	T0TCR=0x00;

}

