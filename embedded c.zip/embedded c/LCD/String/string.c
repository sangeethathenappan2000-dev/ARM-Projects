#include "lcd.h"
typedef unsigned char uc;

void LCD_INTEGER(int n)
{		uc a[5];
		int i=0;

		if(n==0)
		{	LCD_DATA('0'); }
		else
		{
			if(n<0)
				{
				LCD_DATA('-');
				n=-n;
				}
			while(n>0)
			{
			a[i++]=n%10;
			n=n/10;
			}
			for(--i;i>=0;i--)
			{	LCD_DATA(a[i]+48); }
		}

}

int main()
{	int n=234;
   LCD_INIT();
   LCD_COMMAND(0X80);
   LCD_STR("ROLL NO:");
  LCD_COMMAND(0XC0);
   LCD_INTEGER(n);	  
}






