#include "lcd.h"

int main()
{
	LCD_INIT();
	
	while(1)
	{
	LCD_COMMAND(0X80);
	LCD_STR("HELLO WORLD");
	}
}
