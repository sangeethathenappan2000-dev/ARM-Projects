#include<lpc21xx.h>

typedef unsigned char u8;

void delay_ms(u8 ms)
{
	T0PR=15000-1;
	T0TCR=0X01;
	while(T0TC<ms);
	T0TCR=0X03;
	T0TCR=0X00;
}

void delay_us(u8 us)
{
	T0PR=15-1;
	T0TCR=0X01;
	while(T0TC<us);
	T0TCR=0X03;
	T0TCR=0X00;
}
void delay_s(u8 s)
{
	T0PR=15000000-1;
	T0TCR=0X01;
	while(T0TC<s);
	T0TCR=0X03;
	T0TCR=0X00;
}