#include "delay.h"

#define lcd_d 0xff
#define rs 1<<9
#define en 1<<10

typedef unsigned char u8;

void LCD_COMMAND(u8 cmd)
{
//IOPIN0=(IOPIN0&0XFFFFFF00)|cmd;

 IOCLR0=lcd_d;
 IOSET0=cmd;

IOCLR0=rs;
IOSET0=en;
delay_ms(2);
IOCLR0=en;
	
}


void LCD_DATA(u8 data)
{
//IOPIN0=(IOPIN0&0XFFFFFF00)|data;

IOCLR0=lcd_d;
 IOSET0=data;
IOSET0=rs;
IOSET0=en;
delay_ms(2);
IOCLR0=en;
}
void LCD_STR(unsigned char *s)
{
 while(*s)
 	LCD_DATA(*s++);
}

void LCD_INIT()
{
IODIR0=lcd_d|rs|en;

LCD_COMMAND(0x01);
LCD_COMMAND(0x02);
LCD_COMMAND(0x0c);
LCD_COMMAND(0x38);

}
