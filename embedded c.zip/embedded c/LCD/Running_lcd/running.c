#include "lcd.h"			
#include<string.h>
int count=0;
void display(char *s);

int len(char *s)
{
	int i=0;
	for(i=0;s[i];i++);
	return i;
}													   	
int main()
{
unsigned char len,len1,COUNT,cmd;
unsigned char *s="EMBEDDED";

LCD_INIT();

len=strlen("EMBEDDED");
while(1)
{COUNT=0,len1=len;

for(cmd=0x80;cmd<=0x8f;cmd++)
{
	LCD_COMMAND(cmd);
	LCD_STR(s);
	delay_ms(500);
	LCD_COMMAND(0X01);
	COUNT++;
	if(COUNT>(16-len1))
	{
		LCD_COMMAND(0X80);
		len1--;
		LCD_STR(s+len1);
	}
	
	}
	}	
	
}
