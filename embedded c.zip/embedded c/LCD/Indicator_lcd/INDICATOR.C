#include "lcd.h"
#define LED1 1<<16
#define LED2 1<<17
#define SW1 14
#define SW2 15


const unsigned char cgram_lut[]={0x17,0x14,0x14,0x1f,0x05,0x05,0x1d,0x00};
int main()
{	  int i;
	IODIR0=LED1|LED2|LCD_D|RS|E;
	LCD_INIT();
	 IOSET0=LED1|LED2;
	CGRAM_WRITE(8,cgram_lut);
while(1)
{	
	if(((IOPIN0>>SW1)&1)==0)
	{ 
	i=3;
	while(i--)
	{
	LCD_COMMAND(0X01);
	
	LCD_COMMAND(0X80);
	LCD_DATA(0);
	IOCLR0=LED1;
	delay(1);
	IOSET0=LED1;
	//while(((IOPIN0>>SW1)&1)==0);
	LCD_COMMAND(0X01);
	}
	}
	else if(((IOPIN0>>SW2)&1)==0)
	{
	  i=3;
	while(i--)
	{ LCD_COMMAND(0X01);
	
	LCD_COMMAND(0X8F);
	LCD_DATA(0);
	IOCLR0=LED2;
	delay(1);
	IOSET0=LED2;
	//while(((IOPIN0>>SW1)&1)==0);
	LCD_COMMAND(0X01);
	}
	}
 }
 }


	//0x08,0x0c,0x0e,0x0f,0x0e,0x0c,0x08,0x00
			//					,0x02,0x06,0x0e,0x1e,0X0E,0x06,0x02,0x00