#include "delay.h"
typedef unsigned char uc;

#define LCD_D 0xff<<0
#define RS 1<<8
#define E 1<<9

void LCD_COMMAND(unsigned char cmd)
{
	 IOPIN0=(IOPIN0&0xFFFFFF00)|cmd;
	 IOCLR0=RS; //SELECT COMMAND REGISTER
	 IOSET0=E;
	delay_ms(2); 
	IOCLR0=E;
	                                                
}

void LCD_DATA(unsigned char d)
{
	  IOPIN0=(IOPIN0&0xFFFFFF00)|d;
	 IOSET0=RS; //SELECT DATA REGISTER
	 IOSET0=E;
	delay_ms(2); 
	IOCLR0=E;
}
void LCD_STR(unsigned char* S)
{  int COUNT=0;
	while(*S)
	{	if(COUNT==16)
			LCD_COMMAND(0XC0);
		LCD_DATA(*S++); 
		COUNT++;
	}
}

void LCD_INTEGER(int n)
{		uc a[5];
		int i=0;

		if(n==0)
		{	LCD_DATA('0'); }
		else
		{
			if(n<0)
				{
				LCD_DATA('-');
				n=-n;
				}
			while(n>0)
			{
			a[i++]=n%10;
			n=n/10;
			}
			for(--i;i>=0;i--)
			{	LCD_DATA(a[i]+48); }
		}

}

void CGRAM_WRITE(unsigned char nBytes,const unsigned char *lut)
{
	unsigned char i;
	for(i=0;i<nBytes;i++)
		LCD_DATA(lut[i]);
}
	
void LCD_INIT()
{
	   //IODIR0=LCD_D|RS|E;
	   LCD_COMMAND(0X01);
	   LCD_COMMAND(0X02);
	   LCD_COMMAND(0X0C);
	   LCD_COMMAND(0X38);

}