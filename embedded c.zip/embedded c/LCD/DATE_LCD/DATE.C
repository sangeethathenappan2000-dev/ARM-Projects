#include "lcd.h"

const unsigned char cgram_lut[]={0x00,0x00,0x00,0x00,0x00,0x0c,0x12,0x11,
								0x00,0x00,0x00,0x00,0x00,0x06,0x09,0x11,
								0x10,0x10,0x10,0x08,0x04,0x02,0x01,0x00,
								0x01,0x01,0x01,0x02,0x04,0x08,0x10,0x00,
								0x00,0x00,0x00,0x00,0x00,0x0c,0x1E,0x1F,
								0x00,0x00,0x00,0x00,0x00,0x06,0x0F,0x1F,
								0x1F,0x1F,0x1F,0x0F,0x07,0x03,0x01,0x00,
								0x1F,0x1F,0x1F,0x1E,0x1C,0x18,0x10,0x00};


void CGWRITE(unsigned char N)
{
unsigned char i;  
LCD_COMMAND(0X40);
for(i=0;i<N;i++)
	LCD_DATA(cgram_lut[i]);

}

int main()
{
LCD_INIT();

while(1)
{
	LCD_COMMAND(0X85);
	LCD_INTEGER(29);
	LCD_DATA('/');
	LCD_INTEGER(4);
	LCD_DATA('/');
	LCD_INTEGER(25);
	delay(2);
	LCD_COMMAND(0X01);
	
	LCD_COMMAND(0X83);
	LCD_STR("IT'S YOUR");
	LCD_COMMAND(0XC3);
	LCD_STR("BIRTHDAY");
	delay(2);
	
	LCD_COMMAND(0X01);
	LCD_COMMAND(0X80);
	LCD_STR("HAPPY HAPPY");
	LCD_COMMAND(0XC2);
	LCD_STR("BIRTHDAY !!!");
	delay(2);
	LCD_COMMAND(0X01);
	
	CGWRITE(64);
while(1)
{	
	LCD_COMMAND(0X87);
	LCD_DATA(0);
	LCD_DATA(1);
	LCD_COMMAND(0XC7);
	LCD_DATA(2);
	LCD_DATA(3);
	LCD_COMMAND(0X87);
	delay_ms(500);
	LCD_DATA(4);
	LCD_DATA(5);
	LCD_COMMAND(0XC7);
	LCD_DATA(6);
	LCD_DATA(7);
	delay_ms(500);
}
}
}



