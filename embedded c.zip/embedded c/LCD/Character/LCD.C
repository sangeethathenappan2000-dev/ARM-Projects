#include "delay.h"

#define LCD_D 0xff<<0
#define RS 1<<8
#define E 1<<9

void LCD_COMMAND(unsigned char cmd)
{
	IOPIN0=(IOPIN0&0XFFFFFF00)|cmd;
	IOCLR0=RS;
	IOSET0=E;
	delay_ms(2);
	IOCLR0=E;

}

void LCD_DATA(unsigned char d)
{
	IOPIN0=(IOPIN0&0XFFFFFF00)|d;
	IOSET0=RS;
	IOSET0=E;
	delay_ms(2);
	IOCLR0=E;

}


void LCD_INIT()
{
	IODIR0=LCD_D|RS|E;
	LCD_COMMAND(0X01);
	LCD_COMMAND(0X02);
	LCD_COMMAND(0X0C);
	LCD_COMMAND(0X38);
}

int main()
{	//unsigned char ch='A';
	LCD_INIT();

	LCD_COMMAND(0X80);
	LCD_DATA('M');
	LCD_COMMAND(0X81);
	LCD_DATA('e');
	LCD_COMMAND(0X82);
	LCD_DATA('e');
	LCD_COMMAND(0X83);
	LCD_DATA('n');
	LCD_COMMAND(0X84);
	LCD_DATA('a');
	LCD_COMMAND(0X85);
	LCD_DATA('t');
	LCD_COMMAND(0X86);
	LCD_DATA('c');
	LCD_COMMAND(0X87);
	LCD_DATA('h');
	LCD_COMMAND(0X87);
	LCD_DATA('i');

	LCD_COMMAND(0X89);
	LCD_DATA('S');
	LCD_COMMAND(0X8A);
	LCD_DATA('u');
	LCD_COMMAND(0X8B);
	LCD_DATA('g');
	LCD_COMMAND(0X8C);
	LCD_DATA('a');
	LCD_COMMAND(0X8D);
	LCD_DATA('n');

	LCD_COMMAND(0XC5);
	LCD_DATA('S');
	LCD_COMMAND(0XC6);
	LCD_DATA('a');
	LCD_COMMAND(0XC7);
	LCD_DATA('n');
	LCD_COMMAND(0XC8);
	LCD_DATA('g');
	LCD_COMMAND(0XC9);
	LCD_DATA('e');
	LCD_COMMAND(0XCA);
	LCD_DATA('e');
	LCD_COMMAND(0XCB);
	LCD_DATA('t');
	LCD_COMMAND(0XCC);
	LCD_DATA('h');
	LCD_COMMAND(0XCD);
	LCD_DATA('a');
	

	

}


