 #include "lcd.h"

 int main()
 {

 LCD_INIT();
 while(1)
 {
 LCD_COMMAND(0X84);
 LCD_STR("SRI PALANI");
 LCD_COMMAND(0XC0);
 LCD_STR("MURUGAN MEDICALS");
 delay(2);
 LCD_COMMAND(0X01);

 LCD_COMMAND(0X80);
 LCD_STR("QUALITY MEDICINE");
 LCD_COMMAND(0XC3);
 LCD_STR("AT LOW PRICE");
 delay(2);
 LCD_COMMAND(0X01);

 LCD_COMMAND(0X83);
 LCD_STR("CONTACT");
 LCD_COMMAND(0XC3);
 LCD_STR("9894402963");
 delay(2);
  LCD_COMMAND(0X01);

   }

   }

  