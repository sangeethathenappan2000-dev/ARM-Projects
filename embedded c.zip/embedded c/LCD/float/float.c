#include "lcd.h"

void LCD_FLOAT(float X)
{	unsigned char a[5];
	int b[6]={0};
	int i=0,j=0;
	float rem;
	int temp=(int)X;	 //  12
	if(temp==0)
		{	LCD_DATA('0'); }
	else
		{
			while(temp>0)
			{
			a[i++]=temp%10;	       //1,2 are added to array a
			temp=temp/10;
			}
			for(--i;i>=0;i--)
			{	LCD_DATA(a[i]+48); 		//display 1,2
			}
			LCD_DATA('.');				//display .
		  rem=X-(int)X;			   // 12.52-12 = 0.52
		  rem=rem*1000000;	
		  temp=(int)rem;           // 0.52*1000000=520000.00000
		  while(temp>0)
			{
			b[j++]=temp%10;			   //add remaining values to b
			temp=temp/10;
			}
			for(--j;j>=0;j--)
			{	LCD_DATA(b[j]+48);		 // display remaining values
			}
		}
		  
		  }

int main()
{
float x=12.234;
LCD_INIT();
LCD_COMMAND(0X80);
LCD_FLOAT(x);

}
