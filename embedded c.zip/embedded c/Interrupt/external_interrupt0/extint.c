#include<lpc21xx.h>

#define eint0_fun 0X1
#define LED1 1<<0
#define irq_slot 1<<5

void eint0_isr(void) __irq
{
	EXTINT=0X01;
	IOSET0=LED1;
	IOCLR0=LED1;
	VICVectAddr=0;
}

int main()
{  int count=0;

PINSEL1|=eint0_fun;
IODIR0=LED1;

VICIntSelect=0;
VICVectCntl0=irq_slot|14;
VICVectAddr0=(int)eint0_isr;

EXTMODE=0X00;
EXTPOLAR=0X00;

VICIntEnable=1<<14;
while(1)
{
count++;
}
}
