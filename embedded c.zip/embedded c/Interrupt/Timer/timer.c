#include<lpc21xx.h>

#define sw 14
#define led1 1<<0
#define led2 1<<17

int flag=0;

void timer0_isr(void) __irq
{
 T0IR=0X01;

 if(flag==0)
 {
 	IOCLR0=led1;
	flag=1;
		}
	else
	{
	IOSET0=led1;
	flag=0;
	}
	VICVectAddr=0;
}

int main()
{
  IODIR0=led1|led2;
  T0MCR=0x03;
  T0MR0=7500000-1;

  VICIntSelect=0;
  VICVectCntl0=1<<5|4;
  VICVectAddr0=(int)timer0_isr;

  VICIntEnable=1<<4;
  T0TCR=0x01;

  while(1)
  {
  if(((IOPIN0>>sw)&1)==0)
  	IOCLR0=led2;
else
	IOSET0=led2;
	}
	}

	
