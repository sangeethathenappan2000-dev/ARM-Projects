#include<lpc21xx.h>

#define led1 1<<14

void eint0_irq_isr(void) __irq
{	
	EXTINT=0x01;
	IOCLR0=led1;
	IOSET0=led1;
	VICVectAddr=0;
}

int main()
{
	unsigned char count=0;

	IODIR0=led1;
	PINSEL1=0x01;

	VICVectCntl0=1<<5|14;
	VICVectAddr0=(int)eint0_irq_isr;
	EXTMODE=0x01;
	EXTPOLAR=0x00;

	VICIntEnable=1<<14;

	while(1)
	{
	count++;
	}
	}
