#include<lpc21xx.h>

#define led1 1<<14

void nonvect_isr(void) __irq
{
 	EXTINT=0x01;
	IOCLR0=led1;
	IOSET0=led1;
	VICVectAddr=0;

}

int main()
{ unsigned char count=0;
 IODIR0=led1;
 PINSEL1=0x01;
 
 VICIntSelect=0;
 VICDefVectAddr=(int)nonvect_isr;
 
 EXTMODE=0x01;
 EXTPOLAR=0x01;

 VICIntEnable=1<<14;
 while(1)
 {
  	count++;

 }
 	
}