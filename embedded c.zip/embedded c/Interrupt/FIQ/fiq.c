#include<lpc21xx.h>

#define LED1 1<<0
#define LED2 1<<1
#define SW 14

void fiq_isr(void) __irq
{
	EXTINT=0X01;
	IOCLR0=LED1;
	IOSET0=LED1;
	VICVectAddr=0;
}


int main()
{
	IODIR0=LED1|LED2;
	PINSEL1=0X1;
	
	VICIntSelect=1<<14;
	
	EXTMODE=0X00;
	EXTPOLAR=0X00;
	
	VICIntEnable=1<<14;
	
	while(1)
	{
		if(((IOPIN0>>SW)&1)==0)
			IOCLR0=LED2;
		else
			IOSET0=LED2;
	}
}
