#include "defines.h"
#include "spi.c"
#include "lcd.c"
#include<string.h>
#include<stdio.h>


u8 res[20],i=0,j=0;
u8 rxbyte[4];

void tx_fun()
{
	while(res[j]!='\n')
	{
		U0THR=res[j];
		j++;
	}
	i=0,j=0;
}

void isr(void) __irq
{
    u8 iir = U0IIR;
    if ((iir & 0x0E) == 0x04)  // Check for data available
    {
        char ch = U0RBR;

        if (ch == '\n' || i >= 3)  // End of command or overflow
        {
            rxbyte[i] = '\0';  // null-terminate

            if (strncmp(rxbyte, "req", 3) == 0)
            {
                tx_fun();  // Send sensor data
            }

            i = 0;  // reset for next command
        }
        else
        {
            rxbyte[i++] = ch;
        }
    }

    VICVectAddr = 0;  // Clear interrupt in VIC
}

void uart_init()
{	PINSEL0|=0x05;
	U0LCR=0x83;
	U0DLL=97;
	U0LCR=0x03;
}

void uart_int_config()
{
	VICIntSelect=0;
	VICVectCntl0=1<<5|6;
	VICVectAddr0=(int)isr;
	VICIntEnable=1<<6;
	U0IER=(1<<0)|(1<<1);
}

int main()
{	float dry=2.8,wet=1.2;
f32 temp,humid,f;
	lcd_init();
	uart_init();
	uart_int_config();
	spi_init();
	while(1)
	{
		temp = mcp3204_read(0);
		temp = f * 100;	
		 f = mcp3204_read(1);  // This returns voltage
		 humid = ((dry - f) / (dry - wet)) * 100.0;
		 
		 //lcd_float(temp);
		if (humid > 100) humid = 100;
		if (humid < 0) humid = 0;	
		sprintf(res,"T:%d H:%d\n\r",(int)temp,(int)humid);
		lcd_command(0x80);
		lcd_str("Temp:");
		lcd_integer(temp);
		lcd_str(" C");
		lcd_command(0xC0);
		lcd_str("Humid;");
		lcd_integer(humid);										
		lcd_str(" %"); 
		delay_ms(1000);
		
	}
}