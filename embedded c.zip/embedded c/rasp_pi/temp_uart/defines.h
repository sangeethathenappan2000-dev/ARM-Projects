#ifndef _define_
#define _define_

typedef unsigned char u8;
typedef unsigned int u32;
typedef float f32;

#define THRE 5
#define RDR 0

#define mstr_bit 5
#define mode_0 0x00
#define cs 1<<7
#define spif_flag 7
#define pclk 60000000
#define speed 100000
#define spi_speed pclk/speed

#define CS 7
#define SETBIT(WORD,BITPOS)         (WORD|=1<<BITPOS)
#define CLRBIT(WORD,BITPOS)         (WORD&=~(1<<BITPOS))

#endif
