#include<lpc21xx.h>

#include "defines.h"
#include "can.c"
#include "uart.c"
#include "lcd.c"
#include "spi.c"

#define led 1<<0

int temp=0,emp_in=0;
int humid=0,level=0;

CAN_MSG m1;

void can_isr() __irq
{
   	m1.id=C2RID;
	m1.dlc=(C2RFS>>16)&0xF;
	m1.rtr=(C2RFS>>30)&0x1;
	if(m1.rtr==0){ //if data frame
		m1.AByte=C2RDA;
	}
	C2CMR=(1<<2);
	 if(m1.id == 0x01)
	{
		temp = m1.AByte;
	}

	else if(m1.id == 0x02)
	{
		emp_in = m1.AByte;
	}

	else if(m1.id == 0x03)
	{
		level = m1.AByte;
	}
	VICVectAddr = 0;
}
void intr_init()
{
		VICIntSelect &= ~(1 << 27); 	//can interrupt on 27
		VICVectCntl1 = 0x20 | 27;
		VICVectAddr1 = (int)can_isr;
		VICIntEnable |= (1 << 27);
		C2IER |= (1 << 0);

		PINSEL0 &= ~(3 << 28); // Clear bits 29:28
}

int main()
{	//int humid;
	lcd_init();
	uart_init();
	spi_init();
	can_init();
	intr_init();

		IOSET0=led;

		lcd_command(0x80);
	   	lcd_str("DISPLAY UNIT");
		delay_ms(1000);
	while(1)
	{	
		humid=mcp3204_read(0);
		humid*=100;
		lcd_command(0x01);
		lcd_command(0x80);
		lcd_str("EMP IN:");
		lcd_integer(emp_in);
		lcd_str(" Lvl:");
		lcd_integer(level);
		lcd_command(0xc0);
		lcd_str("T:");
		lcd_integer(temp);
		lcd_str("   H:");
		lcd_integer(humid);

			uart_tx_hex(m1.id);
			uart_tx(' ');
			uart_tx_hex(m1.dlc);
			uart_tx(' ');
			uart_tx_hex(m1.AByte);
			uart_tx(' ');
			uart_str("\r\n");
		
	if(temp>25)
	{
		uart_str("Temperature is high\r\n");
		delay_ms(100);
		IOCLR0=led;
	}
	 delay_ms(1000);



}}