//ultrasonic
#include "delay.h"
#include "defines.h"

#define trig 1<<10
#define echo (IOPIN0&(1<<11))

void ultrasonic_init()
{
	IODIR0|=trig;	//SET TRIGGER PIN AS O/P
	T0TCR=0; //STOP TIMER IMMEDIATELY
	T0PR=59; //PRESCALER FOR 1US TICKS(FOR ACCURATE TIMIMNG)
}

void send_pulse()
{
	T0TC=T0PC=0;
	 IOSET0=trig;
	 delay_us(10);
	 IOCLR0=trig;
	}

unsigned int get_range()
{

	unsigned int time=0;
	send_pulse();

	//WAIT FOR ECHO TO GO HIGH
	while(!echo);

	//START MEASURING THE TIME WHEN ECHO GOES HIGH 
	T0TCR=0X01; //START TIMER
	while(echo);
	T0TCR=0X00;

	//THE VALUR OF TC IS THE DURATION OF PULSE IN MICROSECONDS
	time=T0TC;
	//CONVERT TIME TO DISTANCE (DISTNCE= (TIME*SPEED OF SOUND)/2)
	//SPEED OF SOUND= 343 M/S

	if(time<38000)	//IGNORE INVALID RANGES
	{
		time=time/59;  //ADJUST TO ACTUAL DISTANCE
	}
	else
	{
		time=0;  //NO VALID RANGE IF TIME TOO LARGE
	}				
	return time;

}	