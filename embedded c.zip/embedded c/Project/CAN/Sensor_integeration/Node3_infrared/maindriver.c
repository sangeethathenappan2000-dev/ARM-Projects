#include <LPC21xx.H>

#include "lcd.c"
#include "delay.h"
#include "defines.h"
#include"can.c"

#define outpin 16

int main()
{	CAN_MSG m1;
	u32 emp_in=0;
	//int_config();
	lcd_init();
	can_init();

	m1.id=0x02;
	m1.dlc=4;
	m1.rtr=0;

	while(1)
	{
		lcd_command(0x80);	
		
		if(((IOPIN0>>outpin)&1)==0)
		{lcd_command(0xc0);	
		lcd_str("+1");
		delay_ms(500);
		emp_in++;
		lcd_command(0x01);
		}

		lcd_str("EMP IN:");

		lcd_integer(emp_in);
		m1.AByte=emp_in;

	
	 delay_ms(600);
	 can_tx(m1);
	}
}
