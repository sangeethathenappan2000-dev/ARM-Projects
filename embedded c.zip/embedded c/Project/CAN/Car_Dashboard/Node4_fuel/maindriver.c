#include<lpc21xx.h>

#include "delay.h"
#include "defines.h"
#include "4bitmode.h"
#include "spi.c"
#include "can.c"

int main()
{	int fuel;

	CAN_MSG m1;
	lcd_init();
	spi_init();
	can_init();
	m1.id=0x03;
	m1.dlc=4;
	m1.rtr=0;

	while(1)
	{
		fuel=mcp3204_read(0);
		m1.AByte=fuel;
		lcd_command(0x80);
		lcd_float(fuel);
		//delay_ms(300);

		can_tx(m1);
		delay_ms(300);
	}

}

