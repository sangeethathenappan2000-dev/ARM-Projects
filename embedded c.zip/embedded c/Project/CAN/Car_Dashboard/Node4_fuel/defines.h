#ifndef _defines_
#define	_defines_

#define mstr_bit 5
#define mode_0 0x00
#define cs 1<<7
#define spif_flag 7
#define pclk 60000000
#define speed 100000
#define spi_speed pclk/speed

typedef unsigned char u8;
typedef unsigned int u32;
typedef float f32;

#endif