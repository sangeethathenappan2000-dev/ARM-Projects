#include "defines.h"

void spi_init()
{
	PINSEL0=0x1500;//p0.4,p0.5 and p0.6
	S0SPCCR=spi_speed;
	S0SPCR=(1<<mstr_bit)|mode_0;
	IODIR0|=cs;
}

u8 spi_write(u8 data)
{
  u8 stat;
  stat=S0SPSR; //clear SPIF flag
  S0SPDR=data;
  while(((S0SPSR>>spif_flag)&1)==0);
  return S0SPDR;
}

int mcp3204_read(u8 channelNo)
{
	u8 hByte,lByte;
	u32 adc_Val=0;
	f32 val;

	IOPIN0&=~(1<<7); //write 0 on p0.7 to select slave
	spi_write(0x06);  //start condition ->1 and sgl ->1
	hByte=spi_write(channelNo<<6);
	lByte=spi_write(0x00);
	IOPIN0|=(1<<7);  //slave deactivate
	adc_Val=((hByte&0x0f)<<8)|lByte;
	val=(adc_Val*3.3)/4096;
	return adc_Val;

}	

