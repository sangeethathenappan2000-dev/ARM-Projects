#include "4bitmode.c"
#include "defines.h"

u8 cgram_lut[]={0x02,0x06,0x0e,0x1e,0x0e,0x06,0x02,0x00,
				0x08,0x0c,0x0e,0x0f,0x0e,0x0c,0x08,0x00,
				0x00,0x0e,0x0a,0x1b,0x11,0x11,0x11,0x1f,
				0x00,0x0e,0x0a,0x1b,0x11,0x11,0x1f,0x1f,
				0x00,0x0e,0x0a,0x1b,0x1f,0x1f,0x1f,0x1f};


void cgram_write(unsigned char nBytes)
{  
	unsigned char i;
	lcd_command(0x40);
	for(i=0;i<nBytes;i++)
		lcd_data(cgram_lut[i]);
}
void right_indicator()
{  	u8 i;
	for(i=0;i<10;i++)
	{
   		lcd_command(0xcf);
		lcd_data(1);
		delay_ms(300);
		lcd_command(0xcf);
		lcd_data(' ');
		delay_ms(300);
	}
}

void left_indicator()
{
   		u8 i;
	for(i=0;i<10;i++)
	{
		lcd_command(0xc0);
		lcd_data(0);
		delay_ms(300);
		lcd_command(0xc0);
		lcd_data(' ');
		delay_ms(300);
		//lcd_command(0x01);
}
}

void fuel_low()
{
		lcd_command(0x8d);
		lcd_data('F');
		lcd_command(0x8e);
		lcd_data(2);
		lcd_command(0x8f);
		lcd_data('L');
}

void fuel_medium()
{
	  	lcd_command(0x8d);
		lcd_data('F');
		lcd_command(0x8e);
		lcd_data(3);
		lcd_command(0x8f);
		lcd_data('M');
}

void fuel_full()
{
   		lcd_command(0x8d);
		lcd_data('F');
		lcd_command(0x8e);
		lcd_data(4);
		lcd_command(0x8f);
		lcd_data('F');
}
