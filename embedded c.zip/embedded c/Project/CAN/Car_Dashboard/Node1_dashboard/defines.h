//defines 

#ifndef _defines_
#define _defines_

//switch defines
#define sw1 14
#define sw2 16
#define sw3 15

//typedefs
typedef unsigned int u32;
typedef unsigned char u8;
typedef float f32;

#endif