#include<lpc21xx.h>
#include "defines.h"

void i2c_init()
{
	PINSEL0|=0x50;
	I2SCLL=LOAD;
	I2SCLH=LOAD;
	I2CONSET=I2C_EN;

}

void i2c_start()
{
	I2CONSET=1<<STA_BIT;
	while(((I2CONSET>>SI_BIT)&1)==0);
	I2CONCLR=1<<STA_BIT;
}

void i2c_stop()
{
	I2CONSET=1<<STO_BIT;
	I2CONCLR=1<<SI_BIT;
}

void i2c_restart()
{  I2CONSET=1<<STA_BIT;
   	I2CONCLR=1<<SI_BIT;
	while(((I2CONSET>>SI_BIT)&1)==0);
	I2CONCLR=1<<STA_BIT;
	
}

void i2c_write(unsigned char  data)
{
	I2DAT=data;
	I2CONCLR=1<<SI_BIT;
	while(((I2CONSET>>SI_BIT)&1)==0);
}

unsigned char  i2c_nack()
{
 	I2CONSET=0X00;
	I2CONCLR=1<<SI_BIT;
	while(((I2CONSET>>SI_BIT)&1)==0);
	return I2DAT;

}

void rtc_write(unsigned char slave, unsigned char  data_addr, unsigned char  data)
{
	i2c_start();
	i2c_write(slave<<1);
	i2c_write(data_addr);
	i2c_write(data);
	i2c_stop();
	//delay_ms(10);
}

unsigned int  rtc_read(unsigned char  slave, unsigned char  data_addr)
{	
	unsigned char  dat;
	i2c_start();
	i2c_write(slave<<1);
	i2c_write(data_addr);
	i2c_restart();
	i2c_write((slave<<1)|1);
	dat=i2c_nack();
	i2c_stop();
	return dat;

}