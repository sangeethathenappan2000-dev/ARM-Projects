#include<lpc21xx.h>

#include "defines.h"
#include "can.c"
#include "cgram.c"

#define led 1<<0


f32 fuel=0;

CAN_MSG m1,m2;

int main()
{	
	lcd_init();
	can_init();
//	timer_interrupt();

	cgram_write(40);
			m1.id=0x000;
			m1.dlc=4;
			m1.rtr=0;
			m1.AByte=0x00;
	
	while(1)
	{	 lcd_command(0x80);
	   	lcd_str("DISPLAY UNIT");
		//switch press for right and left indicator
		if(((IOPIN0>>sw1)&1)==0)
		{
			m1.id=0x001;	
			can_tx(m1);
			left_indicator();
		}
		if(((IOPIN0>>sw2)&1)==0)
		{
			m1.id=0x002;
			can_tx(m1);
			right_indicator();
		}
		if(((IOPIN0>>sw3)&1)==0)
		{
			if(flag==0)
			{
			m1.id=0x003;
			can_tx(m1);
			lcd_command(0xc4);
			lcd_str("Wiper ON");
			flag=1;
			}
			else if(flag==1)
			{
			m1.id=0x004;
			can_tx(m1);
			lcd_command(0xc4);
			lcd_str("Wiper OFF");
			flag=0;
			}
		}
	delay_ms(100);
	can_rx(&m2);
	fuel=m2.AByte;
	if(fuel<700.0)
	{
		fuel_low();
		delay_ms(100);	
	}
	else if(fuel>=700.0 && fuel<=3500.0)
	{
		fuel_medium();
		delay_ms(100);
	}
	else
	{
		fuel_full();
		delay_ms(100);
	}




}}

		

