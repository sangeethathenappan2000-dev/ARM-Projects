			//defines 

#ifndef _defines_
#define _defines_


//typedefs
typedef unsigned int u32;
typedef unsigned char u8;
typedef float f32;

#endif