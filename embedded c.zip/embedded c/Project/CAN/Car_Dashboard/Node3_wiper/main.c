		  //indicator maindriver

#include<lpc21xx.h>
#include "defines.h"
#include "can.h"
#include "uart.h"

#define led 0xf<<17
#define led1 1<<17

void delay_ms(u32 ms)
{
	 T0PR=60000-1;
	 T0TCR=0x01;
	 while(T0TC<ms);
	 T0TCR=0x03;
	 T0TCR=0x00;
}
void pwm_init()
{ 
	PINSEL0 |=1<<17; /* Configure P0.8 as PWM4*/

    PWMTCR = 0x02; /* Reset and disable counter for PWM */

    PWMPR = 0x1D; /* 29 Prescale Register value  */

    PWMMR0 = 20000; /* Time period f PWM wave, 20msec */

    PWMMR4 = 1000; /* Ton of PWM wave 1 msec */

    PWMMCR = 0x00000002; /* Reset on MR0 match*/

    PWMLER = 0x11; /* Latch enable for PWM3 and PWM0 */

    PWMPCR = 0x1000; /* Enable PWM3 and PWM 0, single edge controlled PWM */

    PWMTCR = 0x09; /* Enable PWM and counter */

}

void wiper_on()
{		
		u32 value;
		u8 i;
		pwm_init();
		for(i=0;i<5;i++)
		{
 		value=500; //0
        PWMMR4 = value; 
        PWMLER = 0x11;
		delay_ms(1000); 
		value=1000;//90
		PWMMR4 = value;
        PWMLER = 0x11;
		delay_ms(1000);
		}
}

int main()
{	
	CAN_MSG m1;
	m1.id=0x00;
	IODIR0|=led;
	can_init();
	uart_init();
	uart_str("Node B data:\r\n");
	IOSET0=led;
  
	while(1)
	{
		can_rx(&m1);
	   if(m1.id==0x03)
		{	uart_str("NODE C received data frame\r\n");
			uart_tx_hex(m1.id);
			uart_tx(' ');
			uart_tx_hex(m1.dlc);
			uart_tx(' ');
			uart_tx_hex(m1.AByte);
			uart_tx(' ');
			uart_str("\r\n");

			wiper_on();
		}
		
		delay_ms(100);
	}

	}
