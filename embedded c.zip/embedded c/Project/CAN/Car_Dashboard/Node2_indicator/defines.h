//defines 
#ifndef _defines_
#define _defines_

typedef unsigned char u8;
typedef unsigned int u32;

//typedefs 

#endif