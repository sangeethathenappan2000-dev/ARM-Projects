//indicator maindriver

#include<lpc21xx.h>
#include "defines.h"
#include "can.c"
#include "uart.c"

#define led 0xf<<17
#define led1 1<<17

void delay_ms(u32 ms)
{
	 T0PR=60000-1;
	 T0TCR=0x01;
	 while(T0TC<ms);
	 T0TCR=0x03;
	 T0TCR=0x00;
}
void right_indicator()
{
	unsigned char i,j=0;
   while(j<5)
   {
	for(i=0;i<3;i++)
	{
		IOCLR0=led1<<i;
		delay_ms(300);
		IOSET0=led1<<i;
		delay_ms(300);
	}
	j++;
	}
}

void left_indicator()
{
    unsigned char i=0;
  
	while(i<5)
	{
		IOCLR0=(led1)<<2;
		delay_ms(300);
		IOSET0=(led1)<<2;
		delay_ms(300);
		IOCLR0=(led1)<<1;
		delay_ms(300);
		IOSET0=(led1)<<1;
		delay_ms(300);
		IOCLR0=(led1)<<0;
		delay_ms(300);
		IOSET0=(led1)<<0;
		delay_ms(300);
		i++;
	}

}

int main()
{	
	CAN_MSG m1;
	m1.id=0x00;
	IODIR0|=led;
	can_init();
	uart_init();
	uart_str("Node B data:\r\n");
	IOSET0=led;
  
	while(1)
	{
		can_rx(&m1);
	   if(m1.id==0x01)
		{	uart_str("NODE B received data frame\r\n");
			uart_tx_hex(m1.id);
			uart_tx(' ');
			uart_tx_hex(m1.dlc);
			uart_tx(' ');
			uart_tx_hex(m1.aByte);
			uart_tx(' ');
			uart_tx_hex(m1.bByte);
			uart_str("\r\n");

			left_indicator();
		}
		if(m1.id==0x02)
		{
			uart_str("NODE B received data frame\r\n");
			uart_tx_hex(m1.id);
			uart_tx(' ');
			uart_tx_hex(m1.dlc);
			uart_tx(' ');
			uart_tx_hex(m1.aByte);
			uart_tx(' ');
			uart_tx_hex(m1.bByte);
			uart_str("\r\n");

			right_indicator();
		}
		delay_ms(100);
	}

	}
