//spi driver
#include "delay.h"
#include "defines.h"

spi_init()
{
  PINSEL0|=0X1500; //P0.4, P0.5, P0.6 AS SCL, MOSI AND MISO
  S0SPCCR=150;    //SET CLK SPEED AS 100KBPS
  S0SPCR  = (1<<MSTR_BIT|Mode_0); 
  IODIR0|=1<<7;	   //for cs 

}

u8 spi_fun(u8 data)
{
   u8 stat;
   stat = S0SPSR;    //clear SPIF 
   S0SPDR = data;   // load spi tx reg
   while(((S0SPSR>>SPIF_BIT)&1)==0); // wait for transmission to complete
   return S0SPDR;    // read data from SPI data reg, place into buffer 
}

f32 Read_ADC_MCP3204(u8 channelNo)

{
  u32 VAL;
  u8 hByte,lByte;

  u32 adcVal=0;
  //select/activate chip 
  CLRBIT(IOPIN0,CS);
  delay_ms(100);
  spi_fun(0x06);
  hByte = spi_fun(channelNo<<6);
  lByte = spi_fun(0x00);
  //de-select/de-activate chp
  SETBIT(IOSET0,CS);
  delay_ms(100);
  adcVal=((hByte&0x0f)<<8)|lByte;
  VAL=((adcVal*3.3)/4096);
  return VAL;
}
