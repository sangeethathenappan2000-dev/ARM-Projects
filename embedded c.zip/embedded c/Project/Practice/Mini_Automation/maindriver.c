#include<lpc21xx.h>

#include "ultrasonic.c"
#include "i2c.c"
#include "4bitmode.h"
#include "delay.h"
#include "spi.c"

#define d_low 30
#define d_full 10
#define motor_pin 1<<18

void motor_ON()
{
	IOCLR0=motor_pin;
}

void motor_OFF()
{
	IOSET0=motor_pin;   
}


int main()
{	
	//u32 sec,hour,min;
	u32 range=0;
	f32 temperature=0;
	VPBDIV=1;   //PCLK AS 60MHZ
	i2c_init();
	lcd_init();
	spi_init();
	ultrasonic_init();
	 IODIR0|=motor_pin;
	 IOSET0=motor_pin;
	while(1)
	{	
		//lcd_command(0x01);

		temperature= Read_ADC_MCP3204(0);

		/*sec=rtc_read(0x68,0x00);
		min=rtc_read(0x68,0x01);
		hour=rtc_read(0x68,0x02); 
		//delay_ms(100);*/

		
		/*lcd_str("Time-");
		lcd_data(hour/16+48);
		lcd_data(hour%16+48);
		lcd_data(':');
		lcd_data(min/16+48);
		lcd_data(min%16+48);
		lcd_data(':');
		lcd_data(sec/16+48);
		lcd_data(sec%16+48);
		 */
		 lcd_command(0x80);
		lcd_str("Temp:");
		lcd_float(temperature*100);

		lcd_command(0xc0);	

		lcd_str("Water lvl:");

		 range=get_range();

		 lcd_data((range/100)+48);	  //hundreds place
		 lcd_data(((range/10)%10)+48); //tens place
		 lcd_data((range%10)+48);	  //ones place
		 lcd_str("cm");

		 if (range >= d_low) {
   	 	// Water level below low threshold � turn ON motor
   		 motor_ON();
			} 
		else if (range <= d_full) {
    	// Water level above full threshold � turn OFF motor
    	motor_OFF();
			}

		 //delay_ms(300);
	}

	}
						    

			