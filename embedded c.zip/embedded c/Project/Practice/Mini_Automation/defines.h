// all defines and typedefs

#ifndef _defines_
#define _defines_

//spi
#define SETBIT(WORD,BITPOS)         (WORD|=1<<BITPOS)
#define CLRBIT(WORD,BITPOS)         (WORD&=~(1<<BITPOS))

#define SPIF_BIT  7 
#define MSTR_BIT 5
#define Mode_0 	0x00
#define CS 7

//i2c speed
#define cclk 60000000
#define i2c_speed 100000
#define pclk cclk/4
#define load_val (pclk/i2c_speed)/2

//i2c bits
#define AA	  2
#define SI	  3
#define STO   4
#define STA	  5
#define I2EN  6

//ultrasonic

#define trig 1<<10
#define echo (IOPIN0&(1<<11))

//typedefs 
typedef unsigned char u8;
typedef unsigned int u32;
typedef float f32;

#endif

