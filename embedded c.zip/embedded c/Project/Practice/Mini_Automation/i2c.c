//i2c header file
#include "delay.h"

#include "defines.h"
void i2c_init()
{
	PINSEL0|=0x50;
	I2SCLL=load_val;
	I2SCLH=load_val;
	I2CONSET=1<<I2EN;
}
void i2c_start()
{
  I2CONSET=1<<STA;
  while(((I2CONSET>>SI)&1)==0);
  I2CONCLR=1<<STA;
}

void i2c_restart()
{
	I2CONCLR=1<<SI;
	I2CONSET=1<<STA;
	while(((I2CONSET>>SI)&1)==0);
}

u8 nack()
{
	I2CONSET=0X00;
	I2CONCLR=1<<SI;
	while(((I2CONSET>>SI)&1)==0);
	return I2DAT;
}


void i2c_stop()
{
  I2CONSET=1<<STO;
  I2CONCLR=1<<SI;
}

void i2c_write(u8 wByte)
{
  I2DAT= wByte;
   I2CONCLR=1<<SI;
   while(((I2CONSET>>SI)&1)==0);
}


void rtc_write(u8 slave, u8 word_addr, u8 data)
{
  i2c_start();
  i2c_write(slave<<1);
  i2c_write(word_addr);
  i2c_write(data);
  i2c_stop();
  delay_ms(10);
}

u8 rtc_read(u8 slave, u8 word_addr)
{ u8 rxByte;
  i2c_start();
  i2c_write(slave<<1);
  i2c_write(word_addr);
  i2c_restart();
  i2c_write(slave<<1|1);
  rxByte=nack();
  i2c_stop();
  return rxByte;

}
