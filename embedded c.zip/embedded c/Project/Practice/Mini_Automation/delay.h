#ifndef _delay_
#define _delay_

void delay_ms(u32 ms)
{
	T0PR=60000-1;
	T0TCR=0X01;
	while(T0TC<ms);
	T0TCR=0X03;
	T0TCR=0X00;
}

#endif