{		lcd_str("Time:");
		//hour
		lcd_data((hour/16)+48);
		lcd_data((hour%16)+48);
		lcd_data(':');
		//min
		lcd_data((min/16)+48);
		lcd_data((min%16)+48);
		lcd_data(':');
		//sec
	 	lcd_data((sec/16)+48);
	    lcd_data((sec%16)+48);

}
			 
void timer_isr(void) __irq
{
		T1IR=0x01;
 	//	sec=rtc_read(0x68,0x00);
	//	min=rtc_read(0x68,0x01);
	//	hour=rtc_read(0x60,0x02);
		IOCLR0=led;
		VICVectAddr=0;
}

void timer_interrupt_init()
{
    //T1TCR=0X02;
	T1MCR = (1<<0)|(1<<1);
 	T1MR0 = 499; 
	VICIntSelect=0;
	VICVectCntl0=1<<5|5;
	VICVectAddr0=(int)timer_isr;
	VICIntEnable=1<<5;
	T1TCR=0X01;
}
