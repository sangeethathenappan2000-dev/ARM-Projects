#include<lpc21xx.h>
#include "4bitmode.h"
#include "ultrasonic.c"

#define d_low 100
#define d_full 10
#define motor_pin 1<<18

void motor_ON()
{
	IOCLR0=motor_pin;
}

void motor_OFF()
{
	IOSET0=motor_pin;   
}

int main()
{	unsigned int range,distance;
	lcd_init();
	ultrasonic_init();
	 IODIR0|=motor_pin;
	while(1)
	{
		lcd_command(0xc0);	
		lcd_str("Water lvl:");

		 range=get_range();
		 //distance=(range*343)/2;

		 lcd_data((range/100)+48);	  //hundreds place
		 lcd_data(((range/10)%10)+48); //tens place
		 lcd_data((range%10)+48);	  //ones place
		 lcd_str("cm");

		 if (distance >= d_low) {
   	 	// Water level below low threshold � turn ON motor
   		 motor_ON();
			} 
		else if (distance <= d_full) {
    	// Water level above full threshold � turn OFF motor
    	motor_OFF();
			}

		 delay_ms(500);
	} 

}