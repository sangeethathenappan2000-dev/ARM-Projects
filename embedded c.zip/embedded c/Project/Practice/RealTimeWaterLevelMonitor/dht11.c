#include <lpc214x.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

void dht11_request(void)
{
	IO0DIR = IO0DIR | 0x00000010;	/* Configure DHT11 pin as output (P0.4 used here) */
	IO0PIN = IO0PIN & 0xFFFFFFEF; /* Make DHT11 pin LOW for minimum 18 seconds */
	delay_ms(20);
	IO0PIN = IO0PIN | 0x00000010; /* Make DHT11 pin HIGH and wait for response */
}

void dht11_response(void)
{
	IO0DIR = IO0DIR & 0xFFFFFFEF;	/* Configure DHT11 pin as output */
	while( IO0PIN & 0x00000010 );	/* Wait till response is HIGH */
	while( (IO0PIN & 0x00000010) == 0 );	/* Wait till response is LOW */
	while( IO0PIN & 0x00000010 );	/* Wait till response is HIGH */	/* This is end of response */
}

uint8_t dht11_data(void)
{
	int8_t count;
	uint8_t data = 0;
	for(count = 0; count<8 ; count++)	/* 8 bits of data */
	{
		while( (IO0PIN & 0x00000010) == 0 );	/* Wait till response is LOW */
		delay_us(30);	/* delay greater than 24 usec */
		if ( IO0PIN & 0x00000010 ) /* If response is HIGH, 1 is received */
			data = ( (data<<1) | 0x01 );
		else	/* If response is LOW, 0 is received */
			data = (data<<1);
		while( IO0PIN & 0x00000010 );	/* Wait till response is HIGH (happens if 1 is received) */
	}
	return data;
}

int main (void)
{
	uint8_t humidity_integer, humidity_decimal, temp_integer, temp_decimal, checksum; 
	char data[7]; 
	UART0_init();
	while(1)
	{
		dht11_request();
		dht11_response();
		humidity_integer = dht11_data();
		humidity_decimal = dht11_data();
		temp_integer = dht11_data();
		temp_decimal = dht11_data();
		checksum = dht11_data();
		if( (humidity_integer + humidity_decimal + temp_integer + temp_decimal) != checksum )
			UART0_SendString("Checksum Error\r\n");
		else
		{			
			UART0_SendString("Relative Humidity : ");
			memset(data, 0, 7);
			sprintf(data, "%d.", humidity_integer);
			UART0_SendString(data);
			memset(data, 0, 7);
			sprintf(data, "%d\r\n", humidity_decimal);
			UART0_SendString(data);
			UART0_SendString("Temperature : ");
			memset(data, 0, 7);
			sprintf(data, "%d.", temp_integer);
			UART0_SendString(data);
			memset(data, 0, 7);
			sprintf(data, "%d\r\n", temp_decimal);
			UART0_SendString(data);
			UART0_SendString("Checksum : ");
			memset(data, 0, 7);
			sprintf(data, "%d\r\n", checksum);
			UART0_SendString(data);			
			delay_ms(1000);
		}
	}
}