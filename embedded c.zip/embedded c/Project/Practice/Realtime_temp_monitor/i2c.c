//i2c DRIVER
#include "4bitmode.h"

#define cclk 60000000
#define pclk cclk/4
#define i2c_speed 100000
#define load_val (pclk/i2c_speed)/2

#define STA	5
#define STO	4
#define SI	3
#define i2c_en  6
void i2c_init()
{
	PINSEL0|=0X50;
	I2SCLL=load_val;
	I2SCLH=load_val;
	I2CONSET=1<<i2c_en;
}
void i2c_start()
{
	I2CONSET=1<<STA;
	while(((I2CONSET>>SI)&1)==0);
	I2CONCLR=1<<STA;	

}

void i2c_write(unsigned char wByte)
{
	I2DAT=wByte;
	I2CONCLR=1<<SI;
	while(((I2CONSET>>SI)&1)==0);
}

void i2c_stop()
{
  I2CONSET=1<<STO;
  I2CONCLR=1<<SI;
}

void i2c_restart()
{
	I2CONCLR=1<<SI;
	I2CONSET=1<<STA;
	while(((I2CONSET>>SI)&1)==0);
	I2CONCLR=1<<STA;
}
unsigned char i2c_nack()
{
	I2CONSET=0X00;
	I2CONCLR=1<<SI;
	while(((I2CONSET>>SI)&1)==0);
	return I2DAT;

	
}

void  i2c_rtc_write(unsigned char slave,unsigned char data_addr, unsigned char data)
{
	i2c_start();
	i2c_write(slave<<1);
	i2c_write(data_addr);
	i2c_write(data);
	i2c_stop();
	delay_ms(10);
}

unsigned char  i2c_rtc_read(unsigned char slave, unsigned char data_addr)
{	
	unsigned char rxByte;
	 i2c_start();
	i2c_write(slave<<1);
	i2c_write(data_addr);
	i2c_restart();
	i2c_write((slave<<1)|1);
	rxByte=i2c_nack();
	i2c_stop();
	return rxByte;

}
