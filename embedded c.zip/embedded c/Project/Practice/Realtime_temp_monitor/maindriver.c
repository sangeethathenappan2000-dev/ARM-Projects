#include<lpc21xx.h>
#include "spi.c"
#include "i2c.c"
#include "uart.c"

int main()
{	unsigned char sec,hour,min;
	float temp,f;

	lcd_init();
	i2c_init();
	uart_init();
	spi_init();

	while(1)
	{
		sec=i2c_rtc_read(0x68,0x00);
		min=i2c_rtc_read(0x68,0x01);
		hour=i2c_rtc_read(0x68,0x02);

		lcd_command(0x80);

		lcd_data((hour/16)+48);
		lcd_data((hour%16)+48);
		lcd_data(':');
		lcd_data((min/16)+48);
		lcd_data((min%16)+48);
		lcd_data(':');
		lcd_data((sec/16)+48);
		lcd_data((sec%16)+48);
		

		lcd_command(0xc0);
		f=mcp3204_read(0);
		temp=f*100;
		lcd_str("Temp:");
		lcd_float(temp);
		lcd_str(" Degree");
		delay_ms(500);

		if(temp>=35.0)
		{
			uart_str("AT\r\n");
			delay_ms(500);
			uart_str("AT+CMGF=1\r\n");
			delay_ms(500);
			uart_str("AT+CMGS=\"+917010839932\"\r\n");
			delay_ms(500);
			uart_str("Temperature is too high\r\n");
			delay_ms(500);
		}
	}
}

