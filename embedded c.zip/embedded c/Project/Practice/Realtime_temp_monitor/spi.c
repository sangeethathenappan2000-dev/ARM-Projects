//spi DRIVER

#define MASTER 	5
#define MODE_0	0x00
#define CS 7

void spi_init()
{
	PINSEL0|=0x1500;
	S0SPCCR=150;
	S0SPCR=(1<<MASTER)|MODE_0;
	IODIR0=1<<7;

}

unsigned char SPI0(unsigned char data)
{
	unsigned char stat=S0SPSR;
	S0SPDR=data;
	while(((S0SPSR>>7)&1)==0);
	return S0SPDR;
}

float mcp3204_read(unsigned char chno)
{
	unsigned char  hByte,lByte;
  unsigned int  adcVal=0;
  //select/activate chip 
  //CLRBIT(IOPIN0,CS);
  IOPIN0&=(~(1<<CS));
	//delay_ms(100);
  SPI0(0x06);
  hByte = SPI0(chno<<6);
  lByte = SPI0(0x00);
	//de-select/de-activate chp
	//SETBIT(IOSET0,CS);
	IOSET0|=(1<<CS);
	//delay_ms(100);
  adcVal=((hByte&0x0f)<<8)|lByte;
  return ((adcVal*3.3)/4096);

}