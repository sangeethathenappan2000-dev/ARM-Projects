//UART driver

#define THRE 5
#define RBR 0

void uart_init()
{
	PINSEL0|=0X05;
	U0LCR=0X83; //DLAB AS 1, TO ACCESS DLL AND DLM
	U0DLL=97;
	U0LCR=0X03;	 //DLAB AS 0, TO ACCESS THR AND RBR
}

void uart_tx(unsigned char txByte)
{
	U0THR=txByte;		 //DATA TO BE TRANSMITTED 
	while(((U0LSR>>THRE)&1)==0);   //WAIT UNTIL THE DATA IS TRANSMITTED
}

unsigned char uart_rx()
{
	while(((U0LSR>>RBR)&1)==0);	 //WAIT UNTIL THE DATA IS RECEIVED
	return U0RBR;			     //RETURN THE RECEIVED DATA
}

void uart_str(unsigned char *s)
{
	while(*s)
	{
		uart_tx(*s++);
		}
}

