#include <lpc214x.h>
#include "4bitmode.h"
#define adc_op 1<<21
#define ain0   1<<0

int adc_read(void);

int main(void)
{
	int voltage;
	float result;
	lcd_init();
	PINSEL1|=1<<22;
	while(1)
	{
	voltage=adc_read();
	result = ( (voltage*3.3/1023) * 100 );
	//moist=a*voltage+b;
	lcd_command(0x80);
	lcd_str("Moisture level:");
	lcd_command(0xc0);
	lcd_float(result);
	delay_ms(500);
	}
}

int adc_read()
{	int result;
	AD0CR|= 0x00200604;	  //select analog input 3 and ADC operational
	AD0CR = AD0CR | (1<<24); //start conversion
	while ( (AD0DR0 & 0x80000000)!=(0x8000000) );//wait until done
	result=AD0DR0;			       //read value from AD0DR0
	result = (result>>6);		   //for extracting lower bits
	result = (result & 0x000003FF);	  //masking the values of lower bits
	return result;
}
