#include<string.h>

void esp_init()
{
	uart_str("AT\r\n");	   //check connection
    delay_ms(2000);

    uart_str("AT+CWMODE=1\r\n");  // Station mode
    delay_ms(2000);

    uart_str("AT+CWJAP=\"vivo 1818\",\"sangeetha\"\r\n"); // Your WiFi
    delay_ms(6000);
}

// Send ADC value to ThingSpeak field1
void ThingSpeak_Update( float temp, float humid) {
    char buffer[200];
    char cmd[50];
    int len;

    // Start TCP connection
    uart_str("AT+CIPSTART=\"TCP\",\"api.thingspeak.com\",80\r\n");
    delay_ms(4000);

    // Correct HTTP GET format
    sprintf(buffer,
        "GET /update?api_key=295DHVHOJJWIJTKG&field1=%f&field2=%f HTTP/1.1\r\nHost: api.thingspeak.com\r\nConnection: close\r\n\r\n",
        temp,humid);

    len = strlen(buffer);

    // Send length first
    sprintf(cmd, "AT+CIPSEND=%d\r\n", len);
    uart_str(cmd);
    delay_ms(2000);

    // Send actual data
    uart_str(buffer);
    delay_ms(4000);
}