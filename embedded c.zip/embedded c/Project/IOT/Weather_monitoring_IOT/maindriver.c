#include<lpc21xx.h>
#include "lcd.c"
#include "spi.c"
#include "uart.c"
#include "esp01.c"

void display(float temp,float humid)
{
		lcd_command(0x80);
		lcd_str("Temp:");
		lcd_float(temp*100);
		lcd_str(" C");
		
		lcd_command(0xc0);
		lcd_str("Humid:");
		lcd_float(humid);
		lcd_str(" %");
}

int main()
{	//int flag=0;
	float temp=0,humid=0;
   uart_init();
   lcd_init();
   spi_init();
   esp_init();
	while(1)
	{
		temp=mcp3204_read(3);
		delay_ms(10);
		humid=mcp3204_read(0);
		display(temp,humid);
		//delay_ms(100);
		ThingSpeak_Update(temp,humid);
		


	/*	if(temp>2.75 && flag==0)
		{
			uart_str("AT\r\n");
			delay_ms(100);
			uart_str("AT+CMGF=1\r\n");
			delay_ms(100);
			uart_str("AT+CMGS=+91**********\r\n");
			delay_ms(100);
			uart_str("Temperature is above 27 degree celcius");
			delay_ms(100);
			flag=1;
		}
		else
		{
		flag=0;
		}	*/

		delay_ms(10000);
	}
}

