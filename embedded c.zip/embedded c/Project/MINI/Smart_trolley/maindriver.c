#include<lpc21xx.h>
#include<string.h>
#include "defines.h"
#include "lcd.c"
#include "trolley_fn.c"
#include  "interrupt.c"

int main()
{	u8 i;
	lcd_init();
	uart_init();
	ext_int_config();
	lcd_command(0x01);
	lcd_command(0x80);
	lcd_str("Smart trolley");
	delay_ms(5000);

	while(1)
	{	lcd_command(0x01);
		lcd_command(0x80);
		lcd_str("Waiting for scan");

		for(i=0;i<12;i++)
		receive_id[i]=uart_rx();
		
		receive_id[i]='\0';

		for(i=0;i<13;i++)
		uart_tx(receive_id[i]);

		if(strcmp(receive_id,pen_id)==0)
		{
		pen_fn();
		}
		else if(strcmp(receive_id,book_id)==0)
		{
		book_fn();
		}
		else
		{
		lcd_command(0x01);
		lcd_command(0x80);
		lcd_str("No match");
		}

		delay_ms(5000);

		if(flag1==1)
		{
			lcd_command(0x01);
			lcd_command(0x80);
			lcd_str("Bill:");
			delay_ms(2000);
			lcd_command(0x01);
			lcd_command(0x80);
			lcd_str("Item  Qty  Price");
			delay_ms(5000);
			lcd_command(0x01);
			lcd_command(0x80);
			lcd_str("Book ");
			lcd_integer(book_count);
			lcd_data(' ');
			lcd_integer(book_amount);
			lcd_command(0xC0);
			lcd_str("Pen  ");
			lcd_integer(pen_count);
			lcd_data(' ');
			lcd_integer(pen_amount);

			delay_ms(5000);
			lcd_command(0x01);
			lcd_command(0x80);
			lcd_str("Total amount ");
			lcd_integer(total_amount);
			delay_ms(3000);
			flag1=0;
		}
		if(flag2==1)
		{
		modify();
		delay_ms(3000);
		flag2=0;
		}
		}

}


