#include<lpc21xx.h>
#include "defines.h"

uart_init()
{
 	PINSEL0|=0x05;	 //uart1
	U0LCR=0x83;
	U0DLL=97;
	U0LCR=0x03;

}

u8 uart_rx()
{	
	while(!((U0LSR>>0)&1));
	return U0RBR;
}

void uart_tx(u8 ch)
{
U0THR=ch;
while(((U0LSR>>5)&1)==0);
}


void uart_str(unsigned char* s)
{
	while(*s)
	{
	uart_tx(*s++);
	}

}