#include<lpc21xx.h>
#include "defines.h"

 void lcd_command(unsigned char cmd)
{
	 
	 IOCLR1=LCD_D;
	 IOSET1=(cmd&0XF0)<<16;
	 
	 IOCLR1=RS; //SELECT COMMAND REGISTER
	 IOSET1=E;
	delay_ms(2); 
	IOCLR1=E; 

	 IOCLR1=LCD_D;
	 IOSET1=(cmd&0X0F)<<20;
	 
	 IOCLR1=RS; //SELECT COMMAND REGISTER
	 IOSET1=E;
	delay_ms(2); 
	IOCLR1=E;
	                                                
}

void lcd_data(unsigned char d)
{
	 IOCLR1=LCD_D;
	 IOSET1=(d&0XF0)<<16;
	 IOSET1=RS; //SELECT DATA REGISTER
	 IOSET1=E;
	delay_ms(2); 
	IOCLR1=E;

	IOCLR1=LCD_D;
	 IOSET1=(d&0X0F)<<20;
	 IOSET1=RS; //SELECT DATA REGISTER
	 IOSET1=E;
	delay_ms(2); 
	IOCLR1=E;
}



void lcd_integer(int n)
{		u8 a[5];
		int i=0;

		if(n==0)
		{	lcd_data('0'); }
		else
		{
			if(n<0)
				{
				lcd_data('-');
				n=-n;
				}
			while(n>0)
			{
			a[i++]=n%10;
			n=n/10;
			}
			for(--i;i>=0;i--)
			{	lcd_data(a[i]+48); }
		}

}

void lcd_str(unsigned char *s)
{
while(*s)
{
lcd_data(*s++);
}
}

void lcd_init()
{
	   IODIR1|=LCD_D|RS|RW|E;
	   IOCLR1=RW;
	   lcd_command(0X01);
	   lcd_command(0x02);
	   lcd_command(0x0c);
	   lcd_command(0x28);

}