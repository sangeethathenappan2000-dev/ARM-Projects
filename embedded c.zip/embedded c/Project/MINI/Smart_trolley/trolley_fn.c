#include "defines.h"
#include "uart.c"

#include<string.h>
int pen_count=0,book_count=0;
int total_amount=0,book_amount=0,pen_amount=0;
int book_price=50,pen_price=30;
u8* book_id= "0600680F3051", *pen_id="0600672F612F";
u8 receive_id[13];

void pen_fn()
{
	pen_count+=1;
	pen_amount+=pen_price;
	lcd_command(0x01);
	lcd_command(0x80);
	lcd_str("Item added..");
	delay_ms(5000);
	lcd_command(0x01);
	lcd_command(0x80);
	lcd_str("Pen 1 No. ");
	total_amount+=pen_price;

}

void book_fn()
{
	book_count+=1;
	book_amount+=book_price;
	lcd_command(0x01);
	lcd_command(0x80);
	lcd_str("Item added..");
	delay_ms(5000);
	lcd_command(0x01);
	lcd_command(0x01);
	lcd_command(0x80);
	lcd_str("Book 1 No. ");
	total_amount+=book_price;

}

void remove_pen_fn()
{
	pen_count-=1;
	pen_amount-=pen_price;
	lcd_command(0x01);
	lcd_command(0x80);
	lcd_str("1 Pen removed..");
	delay_ms(5000);
	lcd_command(0x01);
	total_amount-=pen_price;	
}

void remove_book_fn()
{
	book_count-=1;
	book_amount-=book_price;
	lcd_command(0x01);
	lcd_command(0x80);
	lcd_str("1 book removed..");
	delay_ms(3000);
	lcd_command(0x01);
	total_amount-=book_price;	
}

void modify()
{		u8 i;
		lcd_command(0x01);
		lcd_command(0x80);
		lcd_str("Scan to remove");

		for(i=0;i<12;i++)
		receive_id[i]=uart_rx();
		
		receive_id[i]='\0';

		for(i=0;i<12;i++)
		uart_tx(receive_id[i]);
	    delay_ms(3000);

		if(strcmp(receive_id,pen_id)==0)
		{
		remove_pen_fn();
		delay_ms(3000);
		}
		else if(strcmp(receive_id,book_id)==0)
		{
		remove_book_fn();
		delay_ms(3000);
		}
		else
		{
		lcd_command(0x01);
		lcd_command(0x80);
		lcd_str("No match");
		}


	}