#include<lpc21xx.h>
#include "defines.h"
int flag=0;

void eint0_isr(void) __irq
{
  	EXTINT=0x01;
	flag=1;
	VICVectAddr=0;
}
void ext_int_config()
{	
	PINSEL1|=0x01;		   

	VICIntSelect=0;
	VICVectCntl0=1<<5|14;
	VICVectAddr0=(int)eint0_isr;

	EXTMODE=0x01;
	EXTPOLAR=0x00;

	VICIntEnable=(1<<14);
}


