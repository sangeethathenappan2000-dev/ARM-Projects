#include<lpc21xx.h>
#include "defines.h"
#include "i2c.c"
#include "keyscan.c"
#include "4bitmode.c"
#include "voting.c"
#include "interrupt.c"


#define sw1 14

u32 p1=0,p2=0,p3=0,p4=0;

int main()
{	
	u8 i,val,read[4]={'1','2','3','4'};
	u8 res[4];
	lcd_init();
	i2c_init();
	ext_int_config();

	cgram_write(32);

	lcd_command(0x80);
	lcd_str("Electronic Voting");
	lcd_command(0xc5);
	lcd_str("machine");
	delay_ms(1000);
	 
//	for(i=0;i<4;i++)
//	i2c_eeprom_write(SLAVE_ADDR,i,read[i]);	  //save the pwd to eeprom

	

	while(1)
	{
		lcd_command(0x01);
		lcd_command(0x80);
		lcd_str("Cast your vote:");
		lcd_command(0xc0);

		for(i=0;i<4;i++)
		{						   //display the symbols
		lcd_data((i+1)+48);
		lcd_data(' ');
		lcd_data(i);													                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
		lcd_data(' ');
		}
	
		val=keyscan();			//wait for user input
		

		lcd_command(0x01);
		lcd_command(0x80);
		delay_ms(2000);
		lcd_data(val);

		if(val=='1')
			p1++;
		else if(val=='2')		  //store it into party variable
			p2++;
		else if(val=='3')
			p3++;
		else if(val=='4')
			p4++;

		// delay_ms(2000);
		lcd_command(0x01);
		lcd_command(0x80);
		lcd_str("Vote received");
		delay_ms(2000);

		 if(flag==1)	 //if switch is pressed 
		 {	
			 	get_password(res);
				check_password(res,read,&p1,&p2,&p3,&p4);
				flag=0;
		 }
			delay_ms(2000);
	  }
	}

