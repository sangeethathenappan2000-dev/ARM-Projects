#include<lpc21xx.h>

#include "defines.h"

#ifndef _keyscan_
#define _keyscan_
#define c0 (IOPIN0 & (1<<16))
#define c1 (IOPIN0 & (1<<17))
#define c2 (IOPIN0 & (1<<18))
#define c3 (IOPIN0 & (1<<19))

#define r0 (1<<20)
#define r1 (1<<21)
#define r2 (1<<22)
#define r3 (1<<23)

char keypad[1][4] = {'1','2','3','4'};

char keyscan(void)
{
    unsigned char row, col;

    IODIR0 |= r0 | r1 | r2 | r3;  // rows as output
    IODIR0 &= ~(1<<16 | 1<<17 | 1<<18 | 1<<19); // columns as input

    while(1)
    {
        IOCLR0 |= r0 | r1 | r2 | r3; // clear all rows
        IOSET0 |= r0 | r1 | r2 | r3; // set all rows HIGH

        // scan row 0
        IOCLR0 = r0;
        IOSET0 = r1 | r2 | r3;
        if(!(c0 && c1 && c2 && c3))
        {
            row = 0;
            break;
        }

        // scan row 1
        IOCLR0 = r1;
        IOSET0 = r0 | r2 | r3;
        if(!(c0 && c1 && c2 && c3))
        {
            row = 1;
            break;
        }

        // scan row 2
        IOCLR0 = r2;
        IOSET0 = r0 | r1 | r3;
        if(!(c0 && c1 && c2 && c3))
        {
            row = 2;
            break;
        }

        // scan row 3
        IOCLR0 = r3;
        IOSET0 = r0 | r1 | r2;
        if(!(c0 && c1 && c2 && c3))
        {
            row = 3;
            break;
        }
    }

    // Detect which column is LOW
    if(!c0)
        col = 0;
    else if(!c1)
        col = 1;
    else if(!c2)
        col = 2;
    else
        col = 3;

    delay_ms(250); // debounce
    while(!(c0 && c1 && c2 && c3)); // wait until key released

    return keypad[row][col];
}

#endif