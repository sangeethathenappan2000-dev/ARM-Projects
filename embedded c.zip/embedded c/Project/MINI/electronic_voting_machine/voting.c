#include "4bitmode.c"
#include "keyscan.c"
#ifndef _voting_
#define _voting_
void voting_option(u32 *p1,u32 *p2,u32 *p3,u32 *p4)
{			   char op,i;
				lcd_command(0x01);
				lcd_command(0x80);
				lcd_str("Enter the option:");
				lcd_command(0xc0);
				lcd_str("1. Count 2. Reset");

				op=keyscan();
				lcd_command(0x01);
				lcd_command(0x80);
				lcd_data(op);
			   if(op=='1')
			   {
			    lcd_command(0x01);
				lcd_command(0x80);

				for(i=0;i<4;i++)
				{
				lcd_data(i);
				lcd_data(' ');
				}

				lcd_command(0xc0);
				lcd_integer(*p1);
				lcd_data(' ');
				lcd_integer(*p2);
				lcd_data(' ');
				lcd_integer(*p3);
				lcd_data(' ');
				lcd_integer(*p4);
				
				delay_ms(1000);
				}
				if(op=='2')
				{
				lcd_command(0x01);
				lcd_command(0x80);

				lcd_str("Resetting...");

				*p1=0;
				*p2=0;
				*p3=0;
				*p4=0;

				delay_ms(1000);
				}

}

void check_password(u8* res,u8 *read,u32 *p1,u32*p2, u32*p3,u32*p4)
{		  u32 count=0;
	      int i=0;
			while(i<4)
			{
				if(res[i]==read[i])
					count++;
				i++;
			}

			if(count==4)	   //check if pwds are matching
			{
				voting_option(p1,p2,p3,p4);
				delay_ms(1000);
				}
				else
				{
				lcd_command(0xc0); 
				lcd_str("Pwd no match");
				}
}

void get_password(u8 *res)
{			int i;
			lcd_command(0x01);
			lcd_command(0x80);
			lcd_str("Enter password:");
			lcd_command(0x01);
			lcd_command(0x80);

			for(i=0;i<4;i++)
			{
				res[i]=keyscan();		  //ask for pwd
				lcd_data('*');
			}
		    /*for(i=0;i<4;i++)
			{
			read[i]=i2c_eeprom_read(SLAVE_ADDR,i);	  //read the already saved pwd
			}*/
}
#endif
