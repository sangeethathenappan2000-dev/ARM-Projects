//defines

#ifndef _defines_
#define _defines_

#define SLAVE_ADDR 0x50


typedef unsigned char u8;
typedef unsigned int u32;

#endif
