#include<lpc21xx.h>
#include "defines.h"
int flag=0;
int flag1=0;

void eint0_isr(void) __irq
{
	EXTINT=0x01;
	if(flag1==0)
	{
	IOCLR0|=motor;
	flag1=1;
	}
	 else
	 {
	IOSET0|=motor;
	flag1=0;
	}
	VICVectAddr=0;
}

void eint1_isr(void) __irq
{
  	EXTINT=0x02;
	flag=1;
	VICVectAddr=0;
}
void ext_int_config()
{	
	PINSEL0|=1<<29;
	PINSEL1|=0x01;		   
	//PINSEL0|=1<<31;
	IODIR0|=motor;
	IOSET0|=motor;

	VICIntSelect=0;
	VICVectCntl0=1<<5|eint0;
	VICVectAddr0=(int)eint0_isr;
	VICVectCntl1=1<<5|eint1;
	VICVectAddr1=(int)eint1_isr;

	EXTMODE=0x03;
	EXTPOLAR=0x00;

	VICIntEnable=(1<<eint0)|(1<<eint1);
}


