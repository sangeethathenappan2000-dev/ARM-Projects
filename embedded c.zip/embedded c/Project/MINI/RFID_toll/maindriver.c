//maindriver

#include<lpc21xx.h>
#include<string.h>
#include "defines.h"
#include "uart.h"
#include "interrupt.h"
#include "rfid_fn.h"
#include "pwm_fun.c"
u8* car_id= "0600672F317F", *bike_id="06003B683762", *bus_id="0600680EE989";

int main()
{
  u8 receive_id[13];
  int i,value;
  lcd_init();
  uart_init();
  ext_int_config();
  pwm_init();

  lcd_command(0x80);
  lcd_str("Vehicle Toll");
	lcd_command(0xc5);
  lcd_str("System");
  delay_ms(2000);
  lcd_command(0x01);

  while(1)
  {	lcd_command(0x01);
  	lcd_command(0x80);
	lcd_str("Waiting ...");

	for(i=0;i<12;i++)
  {
  receive_id[i]=uart_rx();
  }
  receive_id[i]='\0';
  delay_ms(1000);

  uart_str(receive_id);

  lcd_command(0x01);
  lcd_command(0x80);
  lcd_str("Received");
  delay_ms(1000);
 
  if(!(strcmp(receive_id,car_id)))
  	car_fun();
  else if(!(strcmp(receive_id,bike_id)))
    bike_fun();
  else if(!(strcmp(receive_id,bus_id)))
    bus_fun();
  else
  	{lcd_command(0x01);
	lcd_command(0x80);
	lcd_str("Not match");
	delay_ms(5000);

	}
   if(flag1==1)
	   {
	   value=500; //0

        PWMMR4 = value; 

        PWMLER = 0x11;

		delay_ms(5000); 

		value=1000;//90

		PWMMR4 = value;

        PWMLER = 0x11;

		delay_ms(5000);
    }
	if(flag==1)
	{
	lcd_command(0x01);
	lcd_command(0x80);
	lcd_str("Total collection:");
	lcd_command(0xc0);
	lcd_integer(total_amount);
	flag=0;
	break;
   }

	 memset(receive_id, 0, sizeof(receive_id));
  }
  
}


