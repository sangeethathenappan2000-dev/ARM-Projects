#include<lpc21xx.h>
#include "defines.h"
#include "lcd.h"

u32 car_price=100, bike_price=50, bus_price=200;
u32 total_amount=0;

void car_fun()
{	lcd_command(0x01);
	lcd_command(0x80);
	lcd_str("Verifying...");
	delay_ms(5000);
	lcd_command(0x01);
	lcd_command(0x80);
	lcd_str("Car: Rs. 20");
	delay_ms(5000);
	lcd_command(0x01);
	lcd_command(0x80);
	lcd_str("You can go...");
	delay_ms(5000);
	lcd_command(0x01);
	lcd_command(0x80);
	lcd_str("Thank you");
	lcd_command(0xc0);
	lcd_str("Visit again");
	delay_ms(5000);
	total_amount+=car_price;
}


void bike_fun()
{
	lcd_command(0x80);
	lcd_str("Verifying...");
	delay_ms(5000);
	lcd_command(0x01);
	lcd_command(0x80);
	lcd_str("Bike: Rs. 20");
	delay_ms(5000);
	lcd_command(0x01);
	lcd_command(0x80);
	lcd_str("You can go...");
	delay_ms(5000);
	lcd_command(0x01);
	lcd_command(0x80);
	lcd_str("Thank you");
	lcd_command(0xc0);
	lcd_str("Visit again");
	delay_ms(5000);
	total_amount+=bike_price;
}


void bus_fun()
{
	lcd_command(0x80);
	lcd_str("Verifying...");
	delay_ms(5000);
	lcd_command(0x01);
	lcd_command(0x80);
	lcd_str("Bus: Rs. 20");
	delay_ms(5000);
	lcd_command(0x01);
	lcd_command(0x80);
	lcd_str("You can go...");
	delay_ms(5000);
	lcd_command(0x01);
	lcd_command(0x80);
	lcd_str("Thank you");
	lcd_command(0xc0);
	lcd_str("Visit again");
	delay_ms(5000);
	total_amount+=bus_price;

}

	