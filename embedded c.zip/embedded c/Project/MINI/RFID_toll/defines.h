#include<lpc21xx.h>

#ifndef _defines_
#define _defines_

#define sw1 14
#define sw2 16

#define eint0 14
#define eint1 15
#define eint2 16

typedef unsigned char u8;
typedef unsigned int u32;

#define LCD_D 0xf<<20
#define RS 1<<17
#define RW 1<<18
#define E 1<<19
#define motor 1<<17

void delay_ms(int s)
{
	T0PR=15000-1;
	T0TCR=0X01;
	while(T0TC<s);
	T0TCR=0x03;
	T0TCR=0x00;
}

#endif
